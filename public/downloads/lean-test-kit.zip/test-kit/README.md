# LEAN test kit: do token-saver plugins cut Claude Code's tokens?

Prompt & Done, 20 Nov 2026. Claude Code 2.1.330, `claude-opus-5-5`, 3 runs per setup.

## Our result (tokens per run, mean of 3)
| Setup | Tokens per run | vs plain |
|---|---|---|
| Plain Claude Code | 232,686 | — |
| rtk 1.2.1 (OSS edition, Bash hook) | 298,849 | +28 % |
| caveman 4.1.0 (Claude Code plugin) | 274,378 | +18 % |
| context-mode 2.2.1 (Claude Code plugin) | 290,908 | +25 % |
| all three | 286,052 | +23 % |

Tokens = input + cache write + cache read + output from `claude -p --output-format stream-json`. All 15 runs solved the task. Run-to-run spread on plain: 192k-259k, so this is "none of them saved tokens on this task", not a precise ranking. API-equivalent dollars were inside the noise (prompt-cache state decides them); see `results/normalized.json`.

## Run it yourself
1. `python3 scripts/make_bench.py bench/pristine` builds the seeded `ledgerly` repo (610 tests, 26 commits, one bad commit, a 9,000-line log). Needs Node 22+ and git.
2. Put the tools inside the kit folder only:
   - rtk: download `rtk-oss-<your-platform>` from github.com/rtk-ai/rtk releases into `tools/rtk-dl/` (no global install). `rtk init -g` with `HOME` set to a scratch folder shows what it would install; `rtk-project-settings.example.json` is the same hook at project level.
   - caveman: `git clone --branch v4.1.0 https://github.com/JuliusBrussee/caveman tools/caveman/repo`
   - context-mode: `git clone https://github.com/mksglu/context-mode tools/context-mode/repo` (its Claude Code plugin is `plugins/claude-code`).
3. `python3 scripts/setup_arms.py` makes sandboxed copies: plugin hooks write their state to `sbhome/`, never to `~/.claude`.
4. `scripts/run_round.sh 1` (then 2, 3) runs plain / rtk / caveman / context-mode / all three on the same prompt; `python3 scripts/summarize.py`, `normalize.py`, `turns.py`, `share.py` print the tables.

Notes: `--setting-sources project` keeps your own settings out; `ENABLE_CLAUDEAI_MCP_SERVERS=false` keeps your claude.ai connectors out (they loaded with `--plugin-dir` and skewed our first pass). Headless `claude -p` starts caveman in manual mode, so the kit sets `CAVEMAN_DEFAULT_MODE=caveman` (its documented opt-in). Each run uses your Claude plan or API usage.

The prompt (`scripts/run_arm.sh`): find the commit that broke the invoice totals, fix it, count the reconcile warnings in the log, add a currency option with tests, make the suite pass, commit.
