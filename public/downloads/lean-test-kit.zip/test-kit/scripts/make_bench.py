#!/usr/bin/env python3
"""Build the seeded `ledgerly` bench repo for the token-saver A/B.

A small Node invoicing library with a 28-commit git history, ~620 node:test
cases (spec reporter, so `npm test` is long) and an app log. Commit 22 of 28
("perf: drop epsilon from roundCents") swaps Math.round for Math.trunc, so
totals that should round up lose a cent and dozens of tests fail.

usage: make_bench.py <out_dir>
"""
import json, os, random, shutil, subprocess, sys

OUT = os.path.abspath(sys.argv[1])
rnd = random.Random(20261120)
if os.path.exists(OUT):
    shutil.rmtree(OUT)
os.makedirs(OUT)


def w(rel, text):
    p = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w") as f:
        f.write(text)


def git(*args, date=None):
    env = dict(os.environ)
    env.update({
        "GIT_AUTHOR_NAME": "Dana Ortiz", "GIT_AUTHOR_EMAIL": "dana@ledgerly.test",
        "GIT_COMMITTER_NAME": "Dana Ortiz", "GIT_COMMITTER_EMAIL": "dana@ledgerly.test",
    })
    if date:
        env["GIT_AUTHOR_DATE"] = date
        env["GIT_COMMITTER_DATE"] = date
    subprocess.run(["git", *args], cwd=OUT, env=env, check=True, capture_output=True)


def commit(msg, date):
    git("add", "-A")
    git("commit", "-q", "-m", msg, date=date)


# ---------------------------------------------------------------- sources
MONEY_GOOD = """'use strict';
// Money helpers. All amounts are plain numbers in major units (e.g. 12.34).

/** Round to whole cents, half up. EPSILON keeps 1.005 from becoming 1.00. */
function roundCents(x) {
  return Math.round((x + Number.EPSILON) * 100) / 100;
}

function toCents(x) {
  return Math.round(roundCents(x) * 100);
}

function fromCents(c) {
  return c / 100;
}

const SYMBOLS = { USD: '$', EUR: '€', GBP: '£', JPY: '¥', CAD: 'CA$', AUD: 'A$' };

function formatMoney(x, currency = 'USD') {
  const sym = SYMBOLS[currency] || currency + ' ';
  const neg = x < 0;
  const fixed = Math.abs(roundCents(x)).toFixed(currency === 'JPY' ? 0 : 2);
  const [whole, frac] = fixed.split('.');
  const grouped = whole.replace(/\\B(?=(\\d{3})+(?!\\d))/g, ',');
  return (neg ? '-' : '') + sym + grouped + (frac ? '.' + frac : '');
}

module.exports = { roundCents, toCents, fromCents, formatMoney, SYMBOLS };
"""

MONEY_BAD = MONEY_GOOD.replace(
    """/** Round to whole cents, half up. EPSILON keeps 1.005 from becoming 1.00. */
function roundCents(x) {
  return Math.round((x + Number.EPSILON) * 100) / 100;
}""",
    """/** Round to whole cents. Integer maths only, no float epsilon (faster). */
function roundCents(x) {
  return Math.trunc(x * 100) / 100;
}""")

REGIONS = {}
for i in range(48):
    code = "R%02d" % (i + 1)
    REGIONS[code] = round(rnd.choice([0.0, 0.025, 0.04, 0.05, 0.0575, 0.06, 0.0625, 0.07, 0.0725, 0.08, 0.0825, 0.0875, 0.095, 0.1, 0.19, 0.2, 0.21]), 4)

TAX = "'use strict';\nconst { roundCents } = require('./money');\n\nconst RATES = " + json.dumps(REGIONS, indent=2) + """;

function rateFor(region) {
  if (!(region in RATES)) throw new Error('unknown region ' + region);
  return RATES[region];
}

function taxFor(amount, region) {
  return roundCents(amount * rateFor(region));
}

module.exports = { RATES, rateFor, taxFor };
"""

CODES = {}
for i in range(40):
    c = rnd.choice(["SPRING", "WELCOME", "LOYAL", "VIP", "BULK", "FRIEND", "STUDENT", "PARTNER"]) + str(rnd.randint(5, 40))
    CODES[c] = rnd.choice([5, 10, 12.5, 15, 20, 25, 30])

DISCOUNTS = "'use strict';\nconst { roundCents } = require('./money');\n\nconst CODES = " + json.dumps(CODES, indent=2) + """;

function discountFor(subtotal, code) {
  if (!code) return 0;
  const pct = CODES[code];
  if (pct === undefined) return 0;
  return roundCents(subtotal * pct / 100);
}

module.exports = { CODES, discountFor };
"""

INVOICE = """'use strict';
const { roundCents } = require('./money');
const { taxFor } = require('./tax');
const { discountFor } = require('./discounts');

function lineTotal(qty, unitPrice) {
  if (qty < 0) throw new Error('negative quantity');
  return roundCents(qty * unitPrice);
}

function subtotal(lines) {
  return roundCents(lines.reduce((s, l) => s + lineTotal(l.qty, l.unitPrice), 0));
}

function invoiceTotal(lines, region, code) {
  const sub = subtotal(lines);
  const disc = discountFor(sub, code);
  const taxable = roundCents(sub - disc);
  const tax = taxFor(taxable, region);
  return { subtotal: sub, discount: disc, tax, total: roundCents(taxable + tax) };
}

module.exports = { lineTotal, subtotal, invoiceTotal };
"""

FXR = {"USD": 1, "EUR": 0.9213, "GBP": 0.7894, "JPY": 151.37, "CAD": 1.3721, "AUD": 1.5318}
CURRENCY = "'use strict';\nconst { roundCents } = require('./money');\n\n// Fixed reference rates per 1 USD (fixture, not live).\nconst PER_USD = " + json.dumps(FXR, indent=2) + """;

function convert(amount, from, to) {
  if (!(from in PER_USD) || !(to in PER_USD)) throw new Error('unknown currency');
  return roundCents(amount / PER_USD[from] * PER_USD[to]);
}

module.exports = { PER_USD, convert };
"""

DATES = """'use strict';

const TERMS = { NET7: 7, NET15: 15, NET30: 30, NET45: 45, NET60: 60, DUE: 0 };

function addDays(iso, days) {
  const d = new Date(iso + 'T00:00:00Z');
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

function dueDate(issued, terms) {
  if (!(terms in TERMS)) throw new Error('unknown terms ' + terms);
  return addDays(issued, TERMS[terms]);
}

function isOverdue(issued, terms, today) {
  return dueDate(issued, terms) < today;
}

module.exports = { TERMS, addDays, dueDate, isOverdue };
"""

CSV = """'use strict';

function esc(v) {
  const s = String(v);
  return /[",\\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
}

function toCsv(rows, columns) {
  const head = columns.map(esc).join(',');
  const body = rows.map(r => columns.map(c => esc(r[c] ?? '')).join(','));
  return [head, ...body].join('\\n');
}

module.exports = { esc, toCsv };
"""

SLUG = """'use strict';

function slugify(s) {
  return s.toLowerCase().normalize('NFKD').replace(/[\\u0300-\\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
}

function invoiceNumber(prefix, seq) {
  return prefix.toUpperCase() + '-' + String(seq).padStart(6, '0');
}

module.exports = { slugify, invoiceNumber };
"""

INDEX = """'use strict';
module.exports = {
  ...require('./money'),
  ...require('./tax'),
  ...require('./discounts'),
  ...require('./invoice'),
  ...require('./currency'),
  ...require('./dates'),
  ...require('./csv'),
  ...require('./slug'),
};
"""

PKG = {
    "name": "ledgerly", "version": "0.9.0", "private": True,
    "description": "Tiny invoicing library: money, tax, discounts, invoices, currency, dates, CSV.",
    "main": "src/index.js",
    "scripts": {"test": "node --test --test-reporter=spec \"test/*.test.js\""},
    "license": "MIT",
}


# ---------------------------------------------------------------- test fixtures
def money_inputs(n):
    out = []
    for _ in range(n):
        cents = rnd.randint(1, 99999)
        frac = rnd.choice([0.1, 0.25, 0.4, 0.5, 0.6, 0.75, 0.9, 0.3, 0.7])
        out.append(round(cents / 100 + frac / 100, 6))
    return out


def node_eval(js):
    r = subprocess.run(["node", "-e", js], cwd=OUT, capture_output=True, text=True, check=True)
    return json.loads(r.stdout)


def write_tests():
    # Expected values come from the correct implementation (run before the bug lands).
    rc_in = money_inputs(60)
    rc_out = node_eval("const m=require('./src/money');console.log(JSON.stringify(%s.map(m.roundCents)))" % json.dumps(rc_in))
    fm_in = [(rnd.choice([1, -1]) * rnd.randint(0, 9999999) / 100, rnd.choice(list(FXR))) for _ in range(70)]
    fm_out = node_eval("const m=require('./src/money');console.log(JSON.stringify(%s.map(([x,c])=>m.formatMoney(x,c))))" % json.dumps(fm_in))
    tx_in = [(rnd.randint(100, 500000) / 100, rnd.choice(list(REGIONS))) for _ in range(70)]
    tx_out = node_eval("const t=require('./src/tax');console.log(JSON.stringify(%s.map(([a,r])=>t.taxFor(a,r))))" % json.dumps(tx_in))
    inv_in = []
    for _ in range(60):
        lines = [{"qty": rnd.randint(1, 12), "unitPrice": rnd.randint(99, 49999) / 100 + rnd.choice([0, 0.005, 0.0025])} for _ in range(rnd.randint(1, 5))]
        inv_in.append((lines, rnd.choice(list(REGIONS)), rnd.choice([None] + list(CODES))))
    inv_out = node_eval("const i=require('./src/invoice');console.log(JSON.stringify(%s.map(([l,r,c])=>i.invoiceTotal(l,r,c))))" % json.dumps(inv_in))
    fx_in = [(rnd.randint(100, 900000) / 100, rnd.choice(list(FXR)), rnd.choice(list(FXR))) for _ in range(60)]
    fx_out = node_eval("const c=require('./src/currency');console.log(JSON.stringify(%s.map(([a,f,t])=>c.convert(a,f,t))))" % json.dumps(fx_in))
    dd_in = [("2026-%02d-%02d" % (rnd.randint(1, 12), rnd.randint(1, 28)), rnd.choice(["NET7", "NET15", "NET30", "NET45", "NET60", "DUE"])) for _ in range(110)]
    dd_out = node_eval("const d=require('./src/dates');console.log(JSON.stringify(%s.map(([i,t])=>d.dueDate(i,t))))" % json.dumps(dd_in))
    words = ["Acme", "Ünïcode", "Café", "Rocket", "North", "Star", "Ltd.", "&", "Co", "Ñandú", "Blue", "Ocean", "42", "Main St"]
    sl_in = [" ".join(rnd.choice(words) for _ in range(rnd.randint(1, 4))) for _ in range(90)]
    sl_out = node_eval("const s=require('./src/slug');console.log(JSON.stringify(%s.map(s.slugify)))" % json.dumps(sl_in))
    cs_in = [[{"a": rnd.choice(["x", "y,z", 'q"uote', "line\nbreak", 12, ""]), "b": rnd.randint(0, 99)} for _ in range(rnd.randint(1, 4))] for _ in range(90)]
    cs_out = node_eval("const c=require('./src/csv');console.log(JSON.stringify(%s.map(r=>c.toCsv(r,['a','b']))))" % json.dumps(cs_in))

    def tfile(name, req, cases):
        body = ["'use strict';", "const test = require('node:test');", "const assert = require('node:assert/strict');", req, ""]
        body += cases
        w("test/" + name, "\n".join(body) + "\n")

    tfile("money.test.js", "const { roundCents, formatMoney } = require('../src/money');",
          ["test('roundCents(%r) is %r', () => { assert.equal(roundCents(%s), %s); });" % (a, b, json.dumps(a), json.dumps(b)) for a, b in zip(rc_in, rc_out)]
          + ["test('formatMoney(%s, %s)', () => { assert.equal(formatMoney(%s, %s), %s); });" % (a, c, json.dumps(a), json.dumps(c), json.dumps(o)) for (a, c), o in zip(fm_in, fm_out)])
    tfile("tax.test.js", "const { taxFor } = require('../src/tax');",
          ["test('tax on %s in %s', () => { assert.equal(taxFor(%s, %s), %s); });" % (a, r, json.dumps(a), json.dumps(r), json.dumps(o)) for (a, r), o in zip(tx_in, tx_out)])
    tfile("invoice.test.js", "const { invoiceTotal } = require('../src/invoice');",
          ["test('invoice #%d (%d lines, %s, %s)', () => { assert.deepEqual(invoiceTotal(%s, %s, %s), %s); });" % (k + 1, len(l), r, c or 'no code', json.dumps(l), json.dumps(r), json.dumps(c), json.dumps(o)) for k, ((l, r, c), o) in enumerate(zip(inv_in, inv_out))])
    tfile("currency.test.js", "const { convert } = require('../src/currency');",
          ["test('convert %s %s to %s', () => { assert.equal(convert(%s, %s, %s), %s); });" % (a, f, t, json.dumps(a), json.dumps(f), json.dumps(t), json.dumps(o)) for (a, f, t), o in zip(fx_in, fx_out)])
    tfile("dates.test.js", "const { dueDate } = require('../src/dates');",
          ["test('due date %s %s', () => { assert.equal(dueDate(%s, %s), %s); });" % (i, t, json.dumps(i), json.dumps(t), json.dumps(o)) for (i, t), o in zip(dd_in, dd_out)])
    tfile("slug.test.js", "const { slugify } = require('../src/slug');",
          ["test('slugify %s', () => { assert.equal(slugify(%s), %s); });" % (json.dumps(s)[1:-1].replace("'", ""), json.dumps(s), json.dumps(o)) for s, o in zip(sl_in, sl_out)])
    tfile("csv.test.js", "const { toCsv } = require('../src/csv');",
          ["test('csv case %d', () => { assert.equal(toCsv(%s, ['a','b']), %s); });" % (k + 1, json.dumps(r), json.dumps(o)) for k, (r, o) in enumerate(zip(cs_in, cs_out))])


def write_log():
    lines = []
    t0 = 1763337600  # 2025-11-17 00:00 UTC base for seconds; label as 2026 below
    paths = ["/api/invoices", "/api/invoices/:id", "/api/quote", "/api/convert", "/healthz", "/api/export.csv"]
    for k in range(9000):
        day = 14 + k // 1800
        hh, mm, ss = (k * 7) // 3600 % 24, (k * 7) // 60 % 60, (k * 7) % 60
        p = rnd.choice(paths)
        lvl = "INFO"
        msg = "%s %s 200 %dms" % (rnd.choice(["GET", "POST"]), p, rnd.randint(3, 180))
        if day >= 17 and p in ("/api/invoices", "/api/quote") and rnd.random() < 0.12:
            lvl = "WARN"
            msg = "POST %s 200 reconcile: total %s != ledger %s (diff 0.01) invoice=INV-%06d" % (p, "{:.2f}".format(rnd.randint(1000, 90000) / 100), "{:.2f}".format(rnd.randint(1000, 90000) / 100), rnd.randint(1, 999999))
        elif rnd.random() < 0.004:
            lvl = "ERROR"
            msg = "GET /api/convert 502 upstream fx timeout after 3000ms"
        lines.append("2026-11-%02dT%02d:%02d:%02d.%03dZ %-5s %s" % (day, hh, mm, ss, rnd.randint(0, 999), lvl, msg))
    w("logs/app.log", "\n".join(lines) + "\n")


# ---------------------------------------------------------------- history
git("init", "-q", "-b", "main")
w(".gitignore", "node_modules/\n*.tgz\n")
w("package.json", json.dumps(PKG, indent=2) + "\n")
w("README.md", "# ledgerly\n\nTiny invoicing library: money, tax, discounts, invoices, currency, dates, CSV.\n\n```js\nconst { invoiceTotal } = require('ledgerly');\ninvoiceTotal([{ qty: 2, unitPrice: 9.99 }], 'R01', 'WELCOME10');\n```\n\nRun the tests with `npm test`.\n")
w("src/money.js", MONEY_GOOD)
commit("chore: scaffold ledgerly with money helpers", "2026-11-03T09:12:00-06:00")

steps = [
    ("src/tax.js", TAX, "feat(tax): regional tax rates and taxFor", "2026-11-03T14:40:00-06:00"),
    ("src/discounts.js", DISCOUNTS, "feat(discounts): percentage discount codes", "2026-11-04T10:05:00-06:00"),
    ("src/invoice.js", INVOICE, "feat(invoice): line totals, subtotal and invoiceTotal", "2026-11-04T16:22:00-06:00"),
    ("src/currency.js", CURRENCY, "feat(currency): convert between six currencies", "2026-11-05T11:30:00-06:00"),
    ("src/dates.js", DATES, "feat(dates): payment terms and due dates", "2026-11-06T09:48:00-06:00"),
    ("src/csv.js", CSV, "feat(csv): CSV export with escaping", "2026-11-06T15:10:00-06:00"),
    ("src/slug.js", SLUG, "feat(slug): slugify and invoice numbers", "2026-11-07T10:02:00-06:00"),
    ("src/index.js", INDEX, "feat: single entry point", "2026-11-07T13:55:00-06:00"),
]
for rel, text, msg, date in steps:
    w(rel, text)
    commit(msg, date)

write_tests()
commit("test: table-driven tests for every module (620 cases)", "2026-11-09T11:20:00-06:00")

small = [
    ("docs: usage examples for currency and dates", "README.md", "\n## Currency\n\n`convert(100, 'USD', 'EUR')` uses fixed fixture rates.\n\n## Dates\n\n`dueDate('2026-11-01', 'NET30')` -> `2026-12-01`.\n", "2026-11-10T09:15:00-06:00"),
    ("chore: add CHANGELOG", "CHANGELOG.md", "# Changelog\n\n## 0.9.0\n- First internal release.\n", "2026-11-10T14:00:00-06:00"),
    ("docs: document discount codes", "docs/discounts.md", "# Discount codes\n\nCodes live in `src/discounts.js`. Unknown codes give no discount.\n", "2026-11-11T10:30:00-06:00"),
    ("chore: editorconfig", ".editorconfig", "root = true\n\n[*]\nindent_style = space\nindent_size = 2\n", "2026-11-11T16:45:00-06:00"),
    ("docs: tax regions table", "docs/tax.md", "# Tax regions\n\n48 fixture regions, R01-R48. Rates in `src/tax.js`.\n", "2026-11-12T09:05:00-06:00"),
    ("ci: run tests on push", ".github/workflows/test.yml", "name: test\non: [push]\njobs:\n  test:\n    runs-on: ubuntu-latest\n    steps:\n      - uses: actions/checkout@v4\n      - uses: actions/setup-node@v4\n        with: { node-version: 24 }\n      - run: npm test\n", "2026-11-12T13:30:00-06:00"),
    ("docs: contributing guide", "CONTRIBUTING.md", "# Contributing\n\nRun `npm test` before every push. Keep money maths in `src/money.js`.\n", "2026-11-13T10:10:00-06:00"),
    ("chore: bump to 0.9.1", "CHANGELOG.md", "# Changelog\n\n## 0.9.1\n- Docs and CI.\n\n## 0.9.0\n- First internal release.\n", "2026-11-14T11:00:00-06:00"),
    ("docs: invoice example output", "docs/invoice.md", "# Invoices\n\n`invoiceTotal(lines, region, code)` returns `{ subtotal, discount, tax, total }`.\n", "2026-11-16T09:40:00-06:00"),
]
for msg, rel, text, date in small:
    p = os.path.join(OUT, rel)
    if rel == "README.md":
        with open(p, "a") as f:
            f.write(text)
    else:
        w(rel, text)
    commit(msg, date)

# The bad commit (22nd of 28).
w("src/money.js", MONEY_BAD)
commit("perf: drop epsilon from roundCents\n\nMath.round with Number.EPSILON showed up in a profile of the export job.\nInteger maths is faster and the tests are table-driven anyway.", "2026-11-17T08:52:00-06:00")

after = [
    ("feat(csv): optional column headers", "src/csv.js", CSV.replace("function toCsv(rows, columns) {\n  const head = columns.map(esc).join(',');", "function toCsv(rows, columns, headers = columns) {\n  const head = headers.map(esc).join(',');"), "2026-11-17T15:20:00-06:00"),
    ("docs: CSV headers option", "docs/csv.md", "# CSV\n\n`toCsv(rows, columns, headers)` writes a header row.\n", "2026-11-18T09:00:00-06:00"),
    ("chore: app log sample for the reconcile job", None, None, "2026-11-18T12:30:00-06:00"),
    ("feat(slug): keep digits in invoice slugs", "src/slug.js", SLUG.replace("function invoiceNumber", "// digits are kept by the [a-z0-9] class above\nfunction invoiceNumber"), "2026-11-18T16:05:00-06:00"),
    ("chore: bump to 0.9.2", "CHANGELOG.md", "# Changelog\n\n## 0.9.2\n- Faster roundCents.\n- CSV headers option.\n\n## 0.9.1\n- Docs and CI.\n\n## 0.9.0\n- First internal release.\n", "2026-11-19T10:15:00-06:00"),
    ("docs: README badge and links", "README.md", None, "2026-11-19T14:40:00-06:00"),
]
for msg, rel, text, date in after:
    if rel is None:
        write_log()
    elif text is None:
        with open(os.path.join(OUT, rel), "a") as f:
            f.write("\nSee `docs/` for module notes. CI runs `npm test` on every push.\n")
    else:
        w(rel, text)
    commit(msg, date)

r = subprocess.run(["git", "log", "--oneline"], cwd=OUT, capture_output=True, text=True)
print(r.stdout)
r = subprocess.run(["npm", "test"], cwd=OUT, capture_output=True, text=True)
tail = r.stdout.strip().splitlines()[-9:]
print("npm test exit", r.returncode)
print("\n".join(tail))
print("stdout bytes", len(r.stdout), "lines", r.stdout.count("\n"))
