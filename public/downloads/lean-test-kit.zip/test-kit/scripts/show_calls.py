import json, sys
for p in sys.argv[1:]:
    print("=====", p)
    for l in open(p):
        try: e = json.loads(l)
        except: continue
        if e.get("type") == "assistant":
            for c in e["message"].get("content", []):
                if c.get("type") == "tool_use":
                    print("  CALL", c["name"], json.dumps(c["input"])[:220])
                elif c.get("type") == "text":
                    print("  TEXT", c["text"][:300].replace("\n", " | "))
        if e.get("type") == "user":
            for c in e["message"].get("content", []) if isinstance(e["message"].get("content"), list) else []:
                if c.get("type") == "tool_result":
                    cont = c.get("content")
                    s = cont if isinstance(cont, str) else json.dumps(cont)
                    print("    RESULT", len(s), "chars:", s[:160].replace("\\n", " | ").replace("\n", " | "))
        if e.get("type") == "result":
            print("  RESULT", e.get("result", "")[:300].replace("\n", " | "))
