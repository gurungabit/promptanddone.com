#!/usr/bin/env python3
"""Prepare the sandboxed tool copies for the token-saver A/B (nothing global).

- plugins/caveman: copy of the caveman v4.1.0 repo (Claude Code plugin root);
  its hook commands get HOME/CLAUDE_CONFIG_DIR pointed at sbhome/ so the mode
  flags land in the sandbox, not ~/.claude.
- plugins/context-mode: copy of context-mode 2.2.1 plugins/claude-code; hooks
  and the MCP server get HOME/CONTEXT_MODE_DATA_DIR pointed at sbhome/.
- rtk-overlay/: the exact files `rtk init -g` wrote into a fake home
  (fakehome-rtkinit/.claude), moved to project level (.claude/settings.json
  hook with the absolute rtk path, RTK.md, CLAUDE.md -> @RTK.md).
- sbhome/: sandbox HOME for the plugin hooks (status line already set, so
  caveman's set-up-your-status-line nudge does not fire; generic git identity).
"""
import json, os, shutil

T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SB = os.path.join(T, "sbhome")
RTK = os.path.join(T, "tools", "rtk-dl", "rtk")

os.makedirs(os.path.join(SB, ".claude"), exist_ok=True)
os.makedirs(os.path.join(SB, ".context-mode"), exist_ok=True)
with open(os.path.join(SB, ".claude", "settings.json"), "w") as f:
    json.dump({"statusLine": {"type": "command", "command": "true"}}, f, indent=2)
with open(os.path.join(SB, ".gitconfig"), "w") as f:
    f.write("[user]\n\tname = Bench Runner\n\temail = bench@ledgerly.test\n")

envp = f'export HOME="{SB}" CLAUDE_CONFIG_DIR="{SB}/.claude" CAVEMAN_DEFAULT_MODE=caveman; '

# caveman
dst = os.path.join(T, "plugins", "caveman")
if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(os.path.join(T, "tools", "caveman", "repo"), dst, ignore=shutil.ignore_patterns(".git"))
pj = os.path.join(dst, ".claude-plugin", "plugin.json")
p = json.load(open(pj))
for ev, groups in p["hooks"].items():
    for g in groups:
        for h in g["hooks"]:
            h["command"] = envp + h["command"]
json.dump(p, open(pj, "w"), indent=2)

# context-mode
dst = os.path.join(T, "plugins", "context-mode")
if os.path.exists(dst):
    shutil.rmtree(dst)
shutil.copytree(os.path.join(T, "tools", "context-mode", "repo", "plugins", "claude-code"), dst)
pj = os.path.join(dst, ".claude-plugin", "plugin.json")
p = json.load(open(pj))
srv = p["mcpServers"]["context-mode"]
p["mcpServers"]["context-mode"] = {"command": "env", "args": [f"HOME={SB}", f"CONTEXT_MODE_DATA_DIR={SB}/.context-mode", srv["command"], *srv["args"]]}
json.dump(p, open(pj, "w"), indent=2)
hj = os.path.join(dst, "hooks", "claude-code.json")
h = json.load(open(hj))
for ev, groups in h["hooks"].items():
    for g in groups:
        for hk in g["hooks"]:
            hk["command"] = f'HOME="{SB}" CONTEXT_MODE_DATA_DIR="{SB}/.context-mode" ' + hk["command"]
json.dump(h, open(hj, "w"), indent=2)

# rtk overlay (project-level copy of what `rtk init -g` writes)
ov = os.path.join(T, "rtk-overlay", ".claude")
os.makedirs(ov, exist_ok=True)
fh = os.path.join(T, "fakehome-rtkinit", ".claude")
s = json.load(open(os.path.join(fh, "settings.json")))
s["hooks"]["PreToolUse"][0]["hooks"][0]["command"] = f'"{RTK}" hook claude'
json.dump(s, open(os.path.join(ov, "settings.json"), "w"), indent=2)
shutil.copy(os.path.join(fh, "RTK.md"), os.path.join(T, "rtk-overlay", "RTK.md"))
with open(os.path.join(T, "rtk-overlay", "CLAUDE.md"), "w") as f:
    f.write(open(os.path.join(fh, "CLAUDE.md")).read())
print("ok", SB)
