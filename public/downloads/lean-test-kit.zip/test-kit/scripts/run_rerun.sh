#!/bin/bash
# Re-run the plugin arms whose first pass loaded claude.ai connectors (caveman, ctxmode, all3), 3 rounds, arms in parallel.
A=$(dirname "$0")
for n in 1 2 3; do for arm in caveman ctxmode all3; do "$A/run_arm.sh" $arm $n & done; wait; done
