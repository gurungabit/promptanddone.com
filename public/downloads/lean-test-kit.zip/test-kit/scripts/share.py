#!/usr/bin/env python3
"""Estimate the share of billed input tokens that was tool (command/file) output: for every API request, the tool output already
in the conversation (chars / 4, rtk's own estimate rule) is counted once per request that re-reads it. Upper-bound-ish estimate."""
import json, glob, os
T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
res = {}
for d in sorted(glob.glob(os.path.join(T, "runs", "*-*"))):
    if not os.path.isdir(d): continue
    seen = set(); cum = 0; acc = 0; billed = 0
    for l in open(os.path.join(d, "stream.jsonl")):
        try: e = json.loads(l)
        except Exception: continue
        if e.get("type") == "assistant":
            m = e["message"]; mid = m.get("id")
            if mid not in seen:
                seen.add(mid); u = m.get("usage") or {}
                billed += u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                acc += cum
        if e.get("type") == "user" and isinstance(e["message"].get("content"), list):
            for c in e["message"]["content"]:
                if c.get("type") == "tool_result":
                    cont = c.get("content"); cum += len(cont if isinstance(cont, str) else json.dumps(cont)) / 4
    res[os.path.basename(d)] = {"billed_input": billed, "tool_output_reread_est": round(acc), "share_pct": round(acc / billed * 100, 1)}
    print(os.path.basename(d), res[os.path.basename(d)])
json.dump(res, open(os.path.join(T, "runs", "tool-output-share.json"), "w"), indent=2)
