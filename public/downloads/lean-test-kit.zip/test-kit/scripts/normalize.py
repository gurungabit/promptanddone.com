#!/usr/bin/env python3
"""Cache-neutral comparison. Dollar cost per run depends on whether the first request's prompt prefix was already cached by an
earlier session (parallel / repeated runs share Anthropic's prompt cache for identical prefixes). Two cache-independent views:
  tokens  = every token Claude processed (input + cache write + cache read + output), summed over all API requests;
  cost_ss = the reported cost with the first request's cache write re-priced as a cache read (steady state: a regular user's
            Claude Code prefix is already cached), using the per-token prices that fit the reported costs exactly."""
import json, glob, os, statistics as st
T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
P_IN, P_W, P_R, P_OUT = 4e-6, 8e-6, 0.2e-6, 20e-6   # least-squares fit to costUSD of all 35 runs, max error 1e-15
out = {}
for d in sorted(glob.glob(os.path.join(T, "runs", "*-*"))):
    if not os.path.isdir(d): continue
    meta = json.load(open(os.path.join(d, "meta.json")))
    req1w = None
    for l in open(os.path.join(d, "stream.jsonl")):
        e = json.loads(l)
        if e.get("type") == "assistant": req1w = e["message"]["usage"].get("cache_creation_input_tokens", 0); break
    tokens = meta["input_tokens"] + meta["cache_creation_input_tokens"] + meta["cache_read_input_tokens"] + meta["output_tokens"]
    cost_ss = meta["total_cost_usd"] - req1w * (P_W - P_R)
    out[os.path.basename(d)] = {"arm": meta["arm"], "tokens": tokens, "cost": meta["total_cost_usd"], "req1_cache_write": req1w, "cost_ss": round(cost_ss, 4), "turns": meta["num_turns"], "wall_s": meta["wall_s"]}
arms = {}
for k, v in out.items(): arms.setdefault(v["arm"], []).append(v)
summ = {}
for a in ["base", "rtk", "caveman", "ctxmode", "all3"]:
    rs = arms[a]; summ[a] = {m: round(st.mean(r[m] for r in rs), 4) for m in ["tokens", "cost", "cost_ss", "turns", "wall_s"]}
    summ[a]["tokens_min"] = min(r["tokens"] for r in rs); summ[a]["tokens_max"] = max(r["tokens"] for r in rs)
    summ[a]["cost_ss_min"] = min(r["cost_ss"] for r in rs); summ[a]["cost_ss_max"] = max(r["cost_ss"] for r in rs)
for a in summ:
    for m in ["tokens", "cost", "cost_ss", "wall_s"]:
        summ[a][m + "_vs_base_pct"] = round((summ[a][m] / summ["base"][m] - 1) * 100, 1)
json.dump({"prices_per_token": {"input": P_IN, "cache_write_1h": P_W, "cache_read": P_R, "output": P_OUT}, "runs": out, "mean": summ}, open(os.path.join(T, "runs", "normalized.json"), "w"), indent=2)
for k, v in out.items(): print(f"{k:11} tokens={v['tokens']:7d} cost={v['cost']:.4f} req1w={v['req1_cache_write']:6d} cost_ss={v['cost_ss']:.4f}")
for a, s in summ.items(): print(f"{a:8} tokens={s['tokens']:9.0f} ({s['tokens_vs_base_pct']:+.1f}%) [{s['tokens_min']}-{s['tokens_max']}]  cost={s['cost']:.4f} ({s['cost_vs_base_pct']:+.1f}%)  cost_ss={s['cost_ss']:.4f} ({s['cost_ss_vs_base_pct']:+.1f}%) [{s['cost_ss_min']}-{s['cost_ss_max']}] turns={s['turns']} wall={s['wall_s']} ({s['wall_s_vs_base_pct']:+.1f}%)")
