#!/usr/bin/env python3
"""Summarize every run in runs/: cost, tokens, turns, wall time, tool-output chars; means per arm. Writes runs/summary.json."""
import json, glob, os, statistics as st, sys
T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
R = sys.argv[1] if len(sys.argv) > 1 else os.path.join(T, "runs")
rows = []
for m in sorted(glob.glob(os.path.join(R, "*-*/meta.json"))):
    d = os.path.dirname(m); meta = json.load(open(m))
    tool_chars = 0; calls = []
    for l in open(os.path.join(d, "stream.jsonl")):
        try: e = json.loads(l)
        except Exception: continue
        if e.get("type") == "assistant":
            for c in e["message"].get("content", []):
                if c.get("type") == "tool_use": calls.append(c["name"])
        if e.get("type") == "user" and isinstance(e["message"].get("content"), list):
            for c in e["message"]["content"]:
                if c.get("type") == "tool_result":
                    cont = c.get("content"); tool_chars += len(cont if isinstance(cont, str) else json.dumps(cont))
    inp = (meta["input_tokens"] or 0) + (meta["cache_creation_input_tokens"] or 0) + (meta["cache_read_input_tokens"] or 0)
    mu = meta.get("model_usage") or {}
    rows.append({"run": os.path.basename(d), "arm": meta["arm"], "n": meta["n"], "cost": meta["total_cost_usd"], "input_all": inp,
                 "cache_write": meta["cache_creation_input_tokens"], "cache_read": meta["cache_read_input_tokens"], "output": meta["output_tokens"],
                 "turns": meta["num_turns"], "wall_s": meta["wall_s"], "tests_pass_after": meta["test_exit_after"] == 0,
                 "tool_calls": len(calls), "tool_names": sorted(set(calls)), "tool_result_chars": tool_chars, "models": list(mu.keys())})
arms = {}
for r in rows: arms.setdefault(r["arm"], []).append(r)
mean = {}
for a, rs in arms.items():
    mean[a] = {k: round(st.mean(x[k] for x in rs), 4) for k in ["cost", "input_all", "cache_write", "cache_read", "output", "turns", "wall_s", "tool_result_chars", "tool_calls"]}
    mean[a]["n"] = len(rs); mean[a]["all_pass"] = all(x["tests_pass_after"] for x in rs)
    mean[a]["cost_min"] = min(x["cost"] for x in rs); mean[a]["cost_max"] = max(x["cost"] for x in rs)
b = mean.get("base")
if b:
    for a, m in mean.items():
        m["cost_vs_base_pct"] = round((m["cost"] / b["cost"] - 1) * 100, 1)
        m["input_vs_base_pct"] = round((m["input_all"] / b["input_all"] - 1) * 100, 1)
        m["output_vs_base_pct"] = round((m["output"] / b["output"] - 1) * 100, 1)
json.dump({"runs": rows, "mean": mean}, open(os.path.join(R, "summary.json"), "w"), indent=2)
print(f"{'run':12} {'cost':>8} {'input':>8} {'cwrite':>7} {'cread':>8} {'out':>6} {'turns':>5} {'wall':>6} {'toolchars':>9}")
for r in rows: print(f"{r['run']:12} {r['cost']:8.4f} {r['input_all']:8d} {r['cache_write']:7d} {r['cache_read']:8d} {r['output']:6d} {r['turns']:5d} {r['wall_s']:6.1f} {r['tool_result_chars']:9d} {r['tool_names']}")
print()
for a in ["base", "rtk", "caveman", "ctxmode", "all3"]:
    if a in mean: m = mean[a]; print(f"{a:8} n={m['n']} cost={m['cost']:.4f} ({m.get('cost_vs_base_pct')}%) range {m['cost_min']:.3f}-{m['cost_max']:.3f} input={m['input_all']:.0f} ({m.get('input_vs_base_pct')}%) out={m['output']:.0f} ({m.get('output_vs_base_pct')}%) turns={m['turns']} wall={m['wall_s']} pass={m['all_pass']}")
