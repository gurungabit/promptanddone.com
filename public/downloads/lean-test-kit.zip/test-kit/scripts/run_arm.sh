#!/bin/bash
# usage: run_arm.sh <arm: base|rtk|caveman|ctxmode|all3> <n>
# Copies the pristine bench and runs one headless Claude Code session on it.
set -u
T=$(cd "$(dirname "$0")/.." && pwd)
arm=$1; n=$2; model=${MODEL:-claude-opus-5-5}
SB=$T/sbhome
d=$T/runs/$arm-$n; rm -rf "$d"; mkdir -p "$d"; cp -R "$T/bench/pristine" "$d/work"; cd "$d/work"
PROMPT='Customers say invoice totals are off by a cent since this week, and npm test is red. 1) Use the git history to find the commit that broke it and fix the root cause. 2) From logs/app.log, tell me how many reconcile warnings were logged and on which endpoints. 3) Add an optional currency argument to invoiceTotal that converts every returned amount with convert() from src/currency.js, with tests. Make the whole suite pass and commit. Finish with three short lines: the bad commit, the warning count, what you added.'
TOOLS="Bash Read Edit Write Grep Glob"
EXTRA=()
use_rtk=0; use_cav=0; use_cm=0
case $arm in
  rtk) use_rtk=1;; caveman) use_cav=1;; ctxmode) use_cm=1;; all3) use_rtk=1; use_cav=1; use_cm=1;; base) ;;
  *) echo "bad arm"; exit 2;;
esac
if [ $use_rtk = 1 ]; then
  cp -R "$T/rtk-overlay/.claude" .claude; cp "$T/rtk-overlay/RTK.md" RTK.md; cp "$T/rtk-overlay/CLAUDE.md" CLAUDE.md
  printf '.claude/\nRTK.md\nCLAUDE.md\n' >> .git/info/exclude
  export PATH="$T/tools/rtk-dl:$PATH" RTK_TELEMETRY_DISABLED=1 RTK_DB_PATH="$d/rtk/history.db" RTK_RECALL_DB="$d/rtk/recall.db" RTK_TEE_DIR="$d/rtk/tee" RTK_AUDIT_DIR="$d/rtk/audit"
  mkdir -p "$d/rtk"
fi
[ $use_cav = 1 ] && EXTRA+=(--plugin-dir "$T/plugins/caveman")
if [ $use_cm = 1 ]; then EXTRA+=(--plugin-dir "$T/plugins/context-mode"); TOOLS="$TOOLS mcp__plugin_context-mode_context-mode"; fi
export ENABLE_CLAUDEAI_MCP_SERVERS=false  # keep claude.ai account connectors out of every arm (they loaded with --plugin-dir)
start=$(python3 -c 'import time;print(time.time())')
claude -p --model "$model" --setting-sources project ${EXTRA[@]+"${EXTRA[@]}"} --allowedTools "$TOOLS" --max-budget-usd 6 --output-format stream-json --verbose "$PROMPT" < /dev/null > "$d/stream.jsonl" 2> "$d/stderr.txt"
end=$(python3 -c 'import time;print(time.time())')
npm test > "$d/test-after.txt" 2>&1; tx=$?
git log --oneline -3 > "$d/git-log-after.txt"
git diff HEAD~1 -- src > "$d/fix.diff" 2>/dev/null
python3 - "$d" "$arm" "$n" "$model" "$start" "$end" "$tx" <<'PY'
import json, sys
d, arm, n, model, s, e, tx = sys.argv[1:]
res = None; init = None
for line in open(d + "/stream.jsonl"):
    try: ev = json.loads(line)
    except Exception: continue
    if ev.get("type") == "result": res = ev
    if ev.get("type") == "system" and ev.get("subtype") == "init": init = ev
json.dump(res, open(d + "/result.json", "w"), indent=2)
u = (res or {}).get("usage", {})
meta = {"arm": arm, "n": int(n), "model": model, "wall_s": round(float(e) - float(s), 1), "test_exit_after": int(tx),
        "total_cost_usd": (res or {}).get("total_cost_usd"), "num_turns": (res or {}).get("num_turns"),
        "input_tokens": u.get("input_tokens"), "cache_creation_input_tokens": u.get("cache_creation_input_tokens"),
        "cache_read_input_tokens": u.get("cache_read_input_tokens"), "output_tokens": u.get("output_tokens"),
        "model_usage": (res or {}).get("modelUsage"),
        "init_tools": (init or {}).get("tools"), "init_mcp": (init or {}).get("mcp_servers"), "init_plugins": (init or {}).get("plugins")}
json.dump(meta, open(d + "/meta.json", "w"), indent=2)
print(json.dumps({k: meta[k] for k in ["arm","n","wall_s","test_exit_after","total_cost_usd","num_turns","input_tokens","cache_creation_input_tokens","cache_read_input_tokens","output_tokens"]}))
PY
