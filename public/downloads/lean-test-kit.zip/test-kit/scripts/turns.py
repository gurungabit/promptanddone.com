#!/usr/bin/env python3
"""Per-run: first-request context size (system prompt + tools + instructions the plugins inject), number of API requests,
and how many characters of tool output entered the conversation. Also rtk's own 'tokens saved' counter."""
import json, glob, os, subprocess, sys
T = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
out = {}
for d in sorted(glob.glob(os.path.join(T, "runs", "*-*"))):
    if not os.path.isdir(d): continue
    first = None; reqs = {}; tool_chars = 0
    for l in open(os.path.join(d, "stream.jsonl")):
        try: e = json.loads(l)
        except Exception: continue
        if e.get("type") == "assistant":
            m = e["message"]; u = m.get("usage") or {}
            mid = m.get("id")
            if mid and mid not in reqs:
                reqs[mid] = u.get("input_tokens", 0) + u.get("cache_creation_input_tokens", 0) + u.get("cache_read_input_tokens", 0)
                if first is None: first = reqs[mid]
        if e.get("type") == "user" and isinstance(e["message"].get("content"), list):
            for c in e["message"]["content"]:
                if c.get("type") == "tool_result":
                    cont = c.get("content"); tool_chars += len(cont if isinstance(cont, str) else json.dumps(cont))
    rec = {"first_request_context_tokens": first, "requests": len(reqs), "tool_output_chars": tool_chars, "tool_output_tokens_est": round(tool_chars / 4)}
    db = os.path.join(d, "rtk", "history.db")
    if os.path.exists(db):
        r = subprocess.run([os.path.join(T, "tools/rtk-dl/rtk"), "gain", "--all", "--format", "json"], capture_output=True, text=True,
                           env={**os.environ, "RTK_DB_PATH": db, "HOME": os.path.join(T, "sbhome")})
        try:
            g = json.loads(r.stdout); rec["rtk_gain"] = g.get("summary", g)
        except Exception: rec["rtk_gain_raw"] = r.stdout[:400]
    out[os.path.basename(d)] = rec
json.dump(out, open(os.path.join(T, "runs", "turns.json"), "w"), indent=2)
for k, v in out.items():
    g = v.get("rtk_gain") or {}
    print(f"{k:11} first={v['first_request_context_tokens']:6} reqs={v['requests']:3} toolchars={v['tool_output_chars']:6} rtk_saved={g.get('total_saved', '')} {g.get('avg_savings_pct', '')}")
