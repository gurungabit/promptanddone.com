#!/bin/bash
# usage: run_round.sh <n>  — runs the five arms of round n in parallel
A=$(dirname "$0")
for arm in base rtk caveman ctxmode all3; do "$A/run_arm.sh" $arm $1 & done; wait
