#!/usr/bin/env node
// Render a reel's scene frame by frame in headless Chromium (Playwright) and encode the frames with ffmpeg.
//
//   node engine/render.mjs example                  -> example/picture.mp4 (silent, 1080x1920, 30 fps)
//   node engine/render.mjs example --stills 0,2,4.5 -> example/stills/*.png + stills/sheet.jpg (look at these)
//   node engine/render.mjs example --serve          -> preview server; open the printed URL in your browser
// Options: --port 8860  --quality 0.93 (JPEG frame quality)  --from S --to S  --keep-frames  --draft
//
// It serves the kit folder on 127.0.0.1:<port>, opens <reel>/scene/index.html if the reel has its own scene
// (else engine/scene/index.html), waits for window.ready, then for every frame i calls window.renderFrame(i / 30)
// and pipes the JPEG into ffmpeg. The scene's draw(t) must be deterministic (see scene.js).
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';
import {chromium} from 'playwright';

const KIT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const VALUED = new Set(['port', 'stills', 'quality', 'from', 'to', 'out']);
const O = {}, positional = [];
for (let i = 2; i < process.argv.length; i++) {
  const a = process.argv[i];
  if (a.startsWith('--')) { const k = a.slice(2); O[k] = VALUED.has(k) ? process.argv[++i] : true; } else positional.push(a);
}
const opt = (name, def) => (O[name] !== undefined && O[name] !== true ? O[name] : def);
const flag = (name) => O[name] === true;
const reelArg = positional[0];
if (!reelArg) { console.error('usage: node engine/render.mjs <reel> [--stills 0,1.5] [--serve] [--port 8860]'); process.exit(2); }

const reelDir = [path.resolve(KIT, reelArg), path.resolve(KIT, 'reels', reelArg)].find((d) => fs.existsSync(path.join(d, 'script.json')));
if (!reelDir) { console.error(`No script.json for reel '${reelArg}' (looked in ${reelArg}/ and reels/${reelArg}/)`); process.exit(2); }
if (!reelDir.startsWith(KIT + path.sep)) { console.error('The reel folder must live inside the kit folder (it is served from there).'); process.exit(2); }
const reelUrl = '/' + path.relative(KIT, reelDir).split(path.sep).join('/') + '/';
const sceneRel = fs.existsSync(path.join(reelDir, 'scene/index.html')) ? path.relative(KIT, path.join(reelDir, 'scene/index.html')) : 'engine/scene/index.html';
const port = +(opt('port', process.env.REELKIT_PORT || 8860));
const FPS = 30;

// ---------------------------------------------------------------- static server (kit folder, localhost only)
const MIME = {'.html': 'text/html', '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.wav': 'audio/wav',
  '.mp3': 'audio/mpeg', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.mp4': 'video/mp4', '.css': 'text/css', '.woff2': 'font/woff2', '.glb': 'model/gltf-binary', '.gltf': 'model/gltf+json'};
const server = http.createServer((req, res) => {
  const p = decodeURIComponent(new URL(req.url, 'http://x').pathname);
  const file = path.resolve(KIT, '.' + p);
  if (!file.startsWith(KIT) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); res.end('not found'); return; }
  res.writeHead(200, {'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-store'});
  fs.createReadStream(file).pipe(res);
});
server.on('error', (e) => { console.error(`Port ${port} is busy (${e.code}). Use --port 8861`); process.exit(1); });
await new Promise((r) => server.listen(port, '127.0.0.1', r));
const pageUrl = `http://127.0.0.1:${port}/${sceneRel.split(path.sep).join('/')}?reel=${reelUrl}`;

if (flag('serve')) {
  console.log(`Preview: ${pageUrl}\n(Space = play/pause; drag the slider to scrub. Ctrl+C to stop.)`);
  await new Promise(() => {});
}

// ---------------------------------------------------------------- browser
const gpuArgs = process.platform === 'darwin' ? ['--use-angle=metal'] : process.platform === 'win32' ? ['--use-angle=d3d11'] : [];
const extra = (process.env.REELKIT_CHROME_ARGS || '').split(' ').filter(Boolean);
const browser = await chromium.launch({headless: true, args: [...gpuArgs, '--ignore-gpu-blocklist', '--enable-gpu-rasterization',
  '--enable-unsafe-swiftshader', '--disable-background-timer-throttling', '--disable-renderer-backgrounding', ...extra]});
const page = await browser.newPage({viewport: {width: 1080, height: 1920}, deviceScaleFactor: 1});
const problems = [];
page.on('pageerror', (e) => problems.push(`pageerror: ${e.message}`));
page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') problems.push(`${m.type()}: ${m.text()}`); });
const t0 = Date.now();
await page.goto(pageUrl + '&render=1');
try { await page.waitForFunction('window.ready === true', null, {timeout: 120000}); }
catch { console.error('Scene never became ready:\n' + problems.join('\n')); await browser.close(); server.close(); process.exit(1); }
const info = await page.evaluate(() => window.sceneInfo);
const renderer = await page.evaluate(() => { const gl = document.createElement('canvas').getContext('webgl2'); const d = gl && gl.getExtension('WEBGL_debug_renderer_info'); return d ? gl.getParameter(d.UNMASKED_RENDERER_WEBGL) : 'unknown'; });
console.log(`scene ready in ${((Date.now() - t0) / 1000).toFixed(1)}s: ${info.duration.toFixed(2)}s, ${info.frames} frames, GPU: ${renderer}${info.draft ? ' [DRAFT timing]' : ''}`);
const grab = async (t, type, q) => {
  const url = await page.evaluate(([t, type, q]) => window.renderFrame(t, type, q), [t, type, q]);
  return Buffer.from(url.slice(url.indexOf(',') + 1), 'base64');
};
const finish = async (code) => {
  const bad = problems.filter((p) => !/GPU stall|GL Driver Message|Automatic fallback to software WebGL/i.test(p));
  if (bad.length) console.log('browser console:\n  ' + bad.slice(-15).join('\n  '));
  await browser.close(); server.close(); process.exit(code);
};

// ---------------------------------------------------------------- stills (+ a contact sheet)
if (opt('stills')) {
  const times = opt('stills').split(',').map(Number).filter((x) => !Number.isNaN(x));
  const dir = path.join(reelDir, 'stills'); fs.mkdirSync(dir, {recursive: true});
  const files = [];
  for (const t of times) {
    const f = path.join(dir, `t${t.toFixed(2).padStart(6, '0')}.png`);
    fs.writeFileSync(f, await grab(t, 'image/png', 1)); files.push(f); console.log(`  ${path.relative(KIT, f)}`);
  }
  const cols = Math.min(4, files.length);
  const inputs = files.flatMap((f) => ['-i', f]);
  const lay = files.map((_, i) => `${(i % cols) * 360}_${Math.floor(i / cols) * 640}`).join('|');
  const fc = files.map((_, i) => `[${i}:v]scale=360:640[v${i}]`).join(';') + ';' + files.map((_, i) => `[v${i}]`).join('')
    + (files.length > 1 ? `xstack=inputs=${files.length}:layout=${lay}:fill=black` : 'null');
  const sheet = path.join(dir, 'sheet.jpg');
  await once(spawn('ffmpeg', ['-v', 'error', '-y', ...inputs, '-filter_complex', fc, '-frames:v', '1', '-q:v', '3', sheet], {stdio: 'inherit'}), 'exit');
  console.log(`contact sheet: ${path.relative(KIT, sheet)} (left to right, top to bottom: ${times.join(', ')} s)`);
  await finish(0);
}

// ---------------------------------------------------------------- full render
if (info.draft && !flag('draft')) {
  console.error('No timeline.json yet: run the voice + ASR gate first (or pass --draft for a timing test).');
  await finish(1);
}
const from = Math.max(0, Math.round(+(opt('from', 0)) * FPS));
const to = Math.min(info.frames, opt('to') ? Math.ceil(+opt('to') * FPS) : info.frames);
const quality = +(opt('quality', 0.93));
const outFile = path.join(reelDir, opt('out', 'picture.mp4'));
const keep = flag('keep-frames') ? path.join(reelDir, 'frames') : null;
if (keep) fs.mkdirSync(keep, {recursive: true});
const ff = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(FPS), '-c:v', 'mjpeg', '-i', '-',
  '-vf', 'scale=in_color_matrix=bt601:in_range=full:out_color_matrix=bt709:out_range=tv,format=yuv420p',
  '-c:v', 'libx264', '-preset', 'medium', '-crf', '12', '-r', String(FPS),
  '-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709', outFile], {stdio: ['pipe', 'inherit', 'inherit']});
const r0 = Date.now();
for (let i = from; i < to; i++) {
  const buf = await grab(i / FPS, 'image/jpeg', quality);
  if (keep) fs.writeFileSync(path.join(keep, `${String(i).padStart(5, '0')}.jpg`), buf);
  if (!ff.stdin.write(buf)) await once(ff.stdin, 'drain');
  if ((i - from + 1) % 60 === 0 || i === to - 1) {
    const s = (Date.now() - r0) / 1000;
    process.stdout.write(`  frame ${i + 1}/${to}  ${((i - from + 1) / s).toFixed(1)} fps\n`);
  }
}
ff.stdin.end();
const [code] = await once(ff, 'exit');
const secs = (Date.now() - r0) / 1000;
console.log(code === 0 ? `wrote ${path.relative(KIT, outFile)}: ${to - from} frames in ${secs.toFixed(1)}s (${((to - from) / secs).toFixed(1)} fps)` : `ffmpeg failed (${code})`);
await finish(code === 0 && !problems.some((p) => p.startsWith('pageerror')) ? 0 : 1);
