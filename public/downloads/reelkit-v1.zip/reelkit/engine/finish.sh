#!/bin/sh
# Mix and encode: <reel>/picture.mp4 + voiceover.wav (+ music.wav and sfx.wav when present) -> <reel>/final.mp4
#
# Mix: the voice gets a gentle compressor; music is side-chain ducked under the voice; SFX sit on top.
# Loudness: measure the premix, apply one gain to reach -14 LUFS integrated, with a peak limiter in front so the
# true peak stays at or under -1.5 dBTP (AAC encoding adds a little, so the limiter aims lower).
# Encode: 1080x1920, 30 fps, H.264 High, yuv420p, BT.709 tags, crf 18 (20 Mbps cap), AAC 256k 48 kHz stereo,
# +faststart (plays before it fully downloads), duration = picture frames / 30.
#
# Usage: sh engine/finish.sh example [--no-music] [--crf 17]
set -e
[ -n "$1" ] || { echo "usage: sh engine/finish.sh <reel> [--no-music] [--crf N]" >&2; exit 2; }
KIT="$(cd "$(dirname "$0")/.." && pwd)"
REEL="$1"; [ -f "$REEL/script.json" ] || REEL="$KIT/$1"; [ -f "$REEL/script.json" ] || REEL="$KIT/reels/$1"
[ -f "$REEL/script.json" ] || { echo "no reel '$1' (expected example/ or reels/<slug>/)" >&2; exit 2; }
shift
NOMUSIC=0; CRF=18
while [ $# -gt 0 ]; do case "$1" in --no-music) NOMUSIC=1; shift;; --crf) CRF="$2"; shift 2;; *) echo "unknown option $1" >&2; exit 2;; esac; done
cd "$REEL"
for f in picture.mp4 voiceover.wav; do [ -f "$f" ] || { echo "missing $REEL/$f" >&2; exit 1; }; done
mkdir -p .work

FRAMES=$(ffprobe -v error -count_frames -select_streams v:0 -show_entries stream=nb_read_frames -of default=nokey=1:noprint_wrappers=1 picture.mp4 | tr -dc '0-9')
DUR=$(awk "BEGIN { printf \"%.4f\", $FRAMES / 30 }")
echo "picture: $FRAMES frames = ${DUR}s"

# ---- 1) premix (48 kHz stereo)
IN="-i voiceover.wav"; N=1
GRAPH="[0:a]aresample=48000,aformat=channel_layouts=stereo,acompressor=threshold=-20dB:ratio=3:attack=5:release=120:makeup=2,apad=whole_dur=$DUR,asplit=2[v][vk]"
MIX="[v]"
if [ "$NOMUSIC" = 0 ] && [ -f music.wav ]; then
  IN="$IN -i music.wav"
  GRAPH="$GRAPH;[$N:a]aresample=48000,aformat=channel_layouts=stereo[m];[m][vk]sidechaincompress=threshold=0.03:ratio=4:attack=20:release=300[md]"
  MIX="$MIX[md]"; N=$((N + 1))
else
  GRAPH="$GRAPH;[vk]anullsink"
fi
if [ -f sfx.wav ]; then
  IN="$IN -i sfx.wav"; GRAPH="$GRAPH;[$N:a]aresample=48000,aformat=channel_layouts=stereo[s]"; MIX="$MIX[s]"; N=$((N + 1))
fi
GRAPH="$GRAPH;${MIX}amix=inputs=$N:normalize=0:duration=first[mix]"
# shellcheck disable=SC2086
ffmpeg -v error -y $IN -filter_complex "$GRAPH" -map "[mix]" -t "$DUR" -c:a pcm_s24le .work/premix.wav

measure() { ffmpeg -hide_banner -nostats -i "$1" -af ebur128=peak=true -f null - 2>&1 | awk '/I:/ {i=$2} /Peak:/ {p=$2} END {print i, p}'; }
set -- $(measure .work/premix.wav); PI="$1"; PP="$2"
GAIN=$(awk "BEGIN { printf \"%.2f\", -14 - $PI }")
LIMIT=$(awk "BEGIN { l = 10 ^ ((-2.3 - $GAIN) / 20); if (l > 1) l = 1; if (l < 0.0625) l = 0.0625; printf \"%.4f\", l }")
echo "premix: ${PI} LUFS, true peak ${PP} dBTP -> gain ${GAIN} dB, limiter ceiling ${LIMIT}"

# ---- 2) limiter + gain -> final mix
ffmpeg -v error -y -i .work/premix.wav -af "alimiter=limit=$LIMIT:attack=2:release=60:level=disabled,volume=${GAIN}dB" -c:a pcm_s24le .work/final-mix.wav
set -- $(measure .work/final-mix.wav)
echo "final mix: $1 LUFS, true peak $2 dBTP"

# ---- 3) encode
ffmpeg -v error -y -i picture.mp4 -i .work/final-mix.wav -map 0:v:0 -map 1:a:0 \
  -vf "setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709:range=tv" \
  -c:v libx264 -preset slow -crf "$CRF" -maxrate 20M -bufsize 40M -profile:v high -pix_fmt yuv420p -r 30 \
  -color_primaries bt709 -color_trc bt709 -colorspace bt709 \
  -c:a aac -b:a 256k -ar 48000 -ac 2 -movflags +faststart -t "$DUR" final.mp4
cp .work/final-mix.wav final-mix.wav
echo "wrote $REEL/final.mp4"
