"""ASR gate + narration assembly.

1. Whisper (faster-whisper) transcribes every take of every line. A take passes only if its normalized words match
   the line's `say` text EXACTLY (no missing, extra or swapped words). The token diff is printed for every take.
2. Among passing takes, pick the one whose pace is closest to asr.target_wps (words per second).
3. Trim silence, apply one global tempo (timing.tempo, 0.85-1.15), join the lines with timing.gap seconds of silence,
   add timing.lead_in and timing.tail, and write <reel>/voiceover.wav (24 kHz mono).
4. Re-transcribe every processed line (it must still match) and take the caption word timings from that audio.
   Writes <reel>/timeline.json (lines + words with start/end in seconds) and <reel>/gate.json (the full report).

Exit code 1 if any line has no passing take: make more takes (voice.py --seeds 3,4,5 --lines ID) or rephrase.

Usage: .venv/bin/python engine/asr_gate.py example [--model small.en] [--pick hook=FILE.wav]
"""
from __future__ import annotations

import argparse
import difflib
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("reel")
ap.add_argument("--model", help="faster-whisper model (default asr.model, e.g. small.en; base.en is faster, medium.en stricter)")
ap.add_argument("--pick", action="append", default=[], help="force a take for a line: LINE=FILENAME (must still pass)")
args = ap.parse_args()

reel = common.reel_dir(args.reel)
S = common.load_script(reel)
A, T, TMAP = S["asr"], S["timing"], S["token_map"]
tempo = float(T["tempo"])
if not 0.85 <= tempo <= 1.15:
    sys.exit(f"timing.tempo {tempo} is outside 0.85-1.15; regenerate at another speed instead")
manifest_path = reel / "takes.json"
if not manifest_path.exists():
    sys.exit(f"No takes yet: run engine/voice.py {args.reel}")
takes = json.loads(manifest_path.read_text())
forced = dict(p.split("=", 1) for p in args.pick)
SR = 24000

from faster_whisper import WhisperModel  # noqa: E402

model_name = args.model or A["model"]
t0 = time.time()
model = WhisperModel(model_name, device="cpu", compute_type="int8")
cache_path = reel / "asr-cache.json"
cache = json.loads(cache_path.read_text()) if cache_path.exists() else {}


def transcribe(path: Path) -> list[dict]:
    key = hashlib.sha256(path.read_bytes()).hexdigest() + "|" + model_name + "|" + A["prompt"]
    if key not in cache:
        segs, _ = model.transcribe(str(path), language="en" if model_name.endswith(".en") else None, beam_size=5,
                                   word_timestamps=True, condition_on_previous_text=False,
                                   initial_prompt=A["prompt"] or None, vad_filter=False)
        cache[key] = [{"text": w.word.strip(), "start": round(w.start, 3), "end": round(w.end, 3)} for s in segs for w in s.words]
        common.save_json(cache_path, cache)
    return cache[key]


def expand(words: list[dict]) -> list[dict]:
    return common.expand_words(words, TMAP)


def trim(a: np.ndarray, sr: int) -> np.ndarray:
    if a.ndim > 1:
        a = a.mean(axis=1)
    hop = int(0.01 * sr)
    rms = np.sqrt(np.convolve(a.astype(np.float64) ** 2, np.ones(hop) / hop, mode="same"))[::hop]
    loud = np.flatnonzero(rms > max(rms.max() * 10 ** (-40 / 20), 1e-4))
    if not len(loud):
        return a
    return a[max(0, loud[0] * hop - int(0.03 * sr)): min(len(a), (loud[-1] + 1) * hop + int(0.08 * sr))]


report, chosen, failed = {}, {}, []
for line in S["lines"]:
    want = common.tokens(line["say"], TMAP)
    cands = []
    for name, m in sorted(takes.items()):
        f = reel / "takes" / name
        if m["line"] != line["id"] or m["say"] != line["say"] or not f.exists():
            continue
        words = transcribe(f)
        got = [x["tok"] for x in expand(words)]
        a, sr = sf.read(f)
        dur = len(trim(a, sr)) / sr
        rate = len(want) / dur * tempo
        ok = got == want
        c = {"take": name, "match": ok, "heard": " ".join(w["text"] for w in words), "words_per_s": round(rate, 2),
             "seconds": round(dur, 2), "diff": [d for d in difflib.ndiff(want, got) if d[0] in "+-"]}
        cands.append(c)
        print(f"{line['id']:>10}  {'PASS' if ok else 'FAIL'}  {rate:4.2f} w/s  {name}  {' '.join(c['diff'])}", flush=True)
    passing = sorted((c for c in cands if c["match"]), key=lambda c: abs(c["words_per_s"] - A["target_wps"]))
    pick = forced.get(line["id"]) or (passing[0]["take"] if passing else None)
    if pick and not any(c["take"] == pick and c["match"] for c in cands):
        sys.exit(f"--pick {line['id']}={pick}: that take did not pass the gate")
    report[line["id"]] = {"expected": " ".join(want), "takes": cands, "chosen": pick}
    print(f"{'':>10}  -> {'chosen: ' + pick if pick else 'NO TAKE PASSED'}", flush=True)
    if not pick:
        failed.append(line["id"])
    else:
        chosen[line["id"]] = pick

if failed:
    common.save_json(reel / "gate.json", {"status": "fail", "failed_lines": failed, "report": report})
    sys.exit(f"\nGATE FAIL: no take matched the script exactly for {failed}.\n"
             f"Fix: more takes (engine/voice.py {args.reel} --lines {','.join(failed)} --seeds 3,4,5,6), "
             f"or rephrase the words Whisper keeps mishearing, or add a token_map entry for a spelling variant.")

# ---------------------------------------------------------------- assemble
pieces = [np.zeros(int(float(T["lead_in"]) * SR), dtype=np.float32)]
t = float(T["lead_in"])
words_out, lines_out = [], []
work = reel / "takes" / "processed"
work.mkdir(exist_ok=True)
for i, line in enumerate(S["lines"]):
    a, sr = sf.read(reel / "takes" / chosen[line["id"]])
    raw = work / f"{line['id']}-trim.wav"
    out = work / f"{line['id']}.wav"
    sf.write(raw, trim(a, sr), sr, subtype="PCM_16")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(raw), "-af", f"atempo={tempo:.4f}", "-ar", str(SR), "-ac", "1",
                    "-c:a", "pcm_s16le", str(out)], check=True)
    b, _ = sf.read(out, dtype="float32")
    toks = expand(transcribe(out))
    want = common.tokens(line["say"], TMAP)
    if [x["tok"] for x in toks] != want:
        sys.exit(f"Line {line['id']}: the processed take no longer matches after tempo {tempo}; lower timing.tempo")
    j = 0
    for shown, said in zip(line["text"].split(), line["say"].split()):
        n = len(common.tokens(said, TMAP))
        if n == 0:  # punctuation-only word: share the previous word's timing
            prev = words_out[-1] if words_out else {"start": t, "end": t}
            words_out.append({"text": shown, "line": line["id"], "start": prev["start"], "end": prev["end"]})
            continue
        s0, s1 = toks[j]["start"], toks[j + n - 1]["end"]
        j += n
        words_out.append({"text": shown, "line": line["id"], "start": round(t + s0, 3), "end": round(t + max(s1, s0 + 0.05), 3)})
    lines_out.append({"id": line["id"], "text": line["text"], "say": line["say"], "start": round(t, 3),
                      "end": round(t + len(b) / SR, 3), "take": chosen[line["id"]]})
    pieces.append(b)
    t += len(b) / SR
    if i < len(S["lines"]) - 1:
        g = float(line.get("gap_after", T["gap"]))
        pieces.append(np.zeros(int(g * SR), dtype=np.float32))
        t += g
pieces.append(np.zeros(int(float(T["tail"]) * SR), dtype=np.float32))
voice = np.concatenate(pieces)
sf.write(reel / "voiceover.wav", voice, SR, subtype="PCM_16")
for k in range(1, len(words_out)):  # keep starts monotonic
    words_out[k]["start"] = max(words_out[k]["start"], words_out[k - 1]["start"])

duration = round(len(voice) / SR, 3)
timeline = {"duration": duration, "fps": 30, "lines": lines_out, "words": words_out,
            "voice": {"engine": takes[next(iter(chosen.values()))]["engine"], "tempo": tempo, "asr_model": model_name}}
common.save_json(reel / "timeline.json", timeline)
common.save_json(reel / "gate.json", {"status": "pass", "chosen": chosen, "report": report})
spoken = words_out[-1]["end"] - words_out[0]["start"]
print(f"\nGATE PASS: {len(S['lines'])} lines, {len(words_out)} words, {duration:.2f}s total, "
      f"{len(words_out) / spoken * 60:.0f} wpm, first word at {words_out[0]['start']:.2f}s ({time.time() - t0:.1f}s)")
print(f"wrote {reel / 'voiceover.wav'} and {reel / 'timeline.json'}")
