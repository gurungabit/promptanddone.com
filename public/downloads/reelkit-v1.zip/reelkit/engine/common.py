"""Shared helpers for the reelkit Python tools.

- reel paths and script loading (script.json -> lines with `text` for captions and `say` for the voice)
- word normalization used by the ASR gate and QA, so "$5", "5 dollars" and "five dollars" compare equal
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

KIT = Path(__file__).resolve().parents[1]

DEFAULTS = {
    "voice": {"engine": "kokoro", "kokoro_voice": "am_michael", "lang": "a", "speeds": [1.0, 1.08], "seeds": [1, 2],
              "reference": None, "exaggeration": 0.5, "cfg": 0.5, "temperature": 0.7},
    "asr": {"model": "small.en", "prompt": "", "target_wps": 3.0},
    "timing": {"lead_in": 0.0, "gap": 0.25, "tail": 0.8, "tempo": 1.0},
    "captions": {"max_words": 4},
    "token_map": {},
}


def reel_dir(arg: str) -> Path:
    """`example`, `reels/my-topic`, `my-topic` or an absolute path -> the folder that holds script.json."""
    p = Path(arg).expanduser()
    for cand in (p, KIT / p, KIT / "reels" / p):
        if (cand / "script.json").is_file():
            return cand.resolve()
    sys.exit(f"No script.json found for reel '{arg}'. Expected example/ or reels/<slug>/script.json")


def load_script(reel: Path) -> dict:
    s = json.loads((reel / "script.json").read_text())
    for key, val in DEFAULTS.items():
        if isinstance(val, dict):
            s[key] = {**val, **s.get(key, {})}
        else:
            s.setdefault(key, val)
    if not s.get("lines"):
        sys.exit("script.json needs a non-empty 'lines' list")
    for i, line in enumerate(s["lines"]):
        line.setdefault("id", f"line{i + 1}")
        line.setdefault("say", line["text"])
        if len(line["text"].split()) != len(line["say"].split()):
            sys.exit(f"Line '{line['id']}': 'text' and 'say' need the same number of words "
                     f"(join a spoken form with hyphens, e.g. '$5' <-> 'five-dollars')")
    return s


def save_json(path: Path, data) -> None:
    Path(path).write_text(json.dumps(data, indent=1, ensure_ascii=False) + "\n")


# ------------------------------------------------------------------ words
def _number_words(token: str) -> list[str]:
    from num2words import num2words  # installed with the kit's requirements
    m = re.fullmatch(r"(\d+)(st|nd|rd|th)", token)
    if m:
        out = num2words(int(m.group(1)), to="ordinal")
    else:
        val = float(token) if "." in token else int(token)
        out = num2words(val)
    return [w for w in re.split(r"[\s,-]+", out) if w and w != "and"]


def tokens(text: str, token_map: dict | None = None) -> list[str]:
    """Normalize a phrase to comparable spoken tokens: lowercase, no punctuation, hyphens split,
    numbers/currency/percent spelled out, then the script's token_map applied (e.g. {"ok": ["okay"]})."""
    tmap = {k.lower(): v for k, v in (token_map or {}).items()}
    text = text.replace("&", " and ").replace("’", "'").replace("—", " ").replace("–", " ")
    out: list[str] = []
    for raw in text.split():
        raw = raw.lower().strip(".,!?;:\"()[]{}…")
        key = re.sub(r"[^a-z0-9$%.']", "", raw).replace("'", "")
        if key in tmap:
            out += tmap[key]
            continue
        for part in re.split(r"-+", raw):
            part = part.replace("'", "")
            money = part.startswith("$")
            pct = part.endswith("%")
            core = re.sub(r"[^a-z0-9.]", "", part.replace(",", "")).strip(".")
            if not core:
                continue
            if core in tmap:
                out += tmap[core]
            elif re.fullmatch(r"\d+(\.\d+)?|\d+(st|nd|rd|th)", core):
                out += _number_words(core)
            else:
                out += [core.replace(".", "")] if not re.fullmatch(r"[a-z]+(\.[a-z]+)+", core) else core.split(".")
            if money:
                out.append("dollars")
            if pct:
                out.append("percent")
    return out


def expand_words(words: list[dict], token_map: dict | None = None) -> list[dict]:
    """ASR words ({text, start, end}) -> normalized tokens; a word that expands ("$5" -> five dollars) splits its time."""
    out = []
    for w in words:
        toks = tokens(w["text"], token_map)
        d = (w["end"] - w["start"]) / max(len(toks), 1)
        out += [{"tok": t, "start": w["start"] + i * d, "end": w["start"] + (i + 1) * d} for i, t in enumerate(toks)]
    return out
