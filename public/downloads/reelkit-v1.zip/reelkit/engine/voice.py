"""Voice takes: synthesize every line of a reel's script.json several times, so the ASR gate can pick a clean one.

Engines (script.json "voice.engine"):
  kokoro      default. Kokoro-82M (Apache-2.0), runs on CPU. One take per speed x seed in voice.speeds / voice.seeds.
              Pick a voice with voice.kokoro_voice (am_michael, am_puck, af_heart, af_bella, bm_george, ...).
  chatterbox  optional voice cloning (MIT) from a 10-15 s WAV of a voice you own: voice.reference = "path.wav".
              One take per seed. Needs its own env (requirements-chatterbox.txt); see README.

Takes land in <reel>/takes/<line>-<engine>-<variant>-<hash>.wav (the hash covers text + settings, so a changed
line makes new takes and old ones are never overwritten). Every take is listed in <reel>/takes.json.

Usage: .venv/bin/python engine/voice.py example [--lines hook,cta] [--seeds 1,2,3]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("reel", help="example, reels/<slug> or <slug>")
ap.add_argument("--lines", help="comma-separated line ids (default: all)")
ap.add_argument("--seeds", help="override voice.seeds, e.g. 3,4,5")
ap.add_argument("--engine", choices=["kokoro", "chatterbox"], help="override voice.engine")
args = ap.parse_args()

reel = common.reel_dir(args.reel)
S = common.load_script(reel)
V = S["voice"]
engine = args.engine or V["engine"]
seeds = [int(x) for x in args.seeds.split(",")] if args.seeds else [int(x) for x in V["seeds"]]
only = set(args.lines.split(",")) if args.lines else None
lines = [ln for ln in S["lines"] if not only or ln["id"] in only]
if only and len(lines) != len(only):
    sys.exit(f"Unknown line ids: {sorted(only - {ln['id'] for ln in S['lines']})}")

takes_dir = reel / "takes"
takes_dir.mkdir(exist_ok=True)
manifest_path = reel / "takes.json"
manifest = json.loads(manifest_path.read_text()) if manifest_path.exists() else {}

import logging  # noqa: E402
import warnings  # noqa: E402

warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
logging.getLogger("torch.distributed.elastic.multiprocessing.redirects").setLevel(logging.ERROR)
import numpy as np  # noqa: E402
import soundfile as sf  # noqa: E402
import torch  # noqa: E402

t_start = time.time()
if engine == "kokoro":
    from kokoro import KPipeline  # noqa: E402
    pipe = None
    variants = [(float(sp), sd) for sp in V["speeds"] for sd in seeds]
    for line in lines:
        for speed, seed in variants:
            sig = hashlib.sha256(f"kokoro|{line['say']}|{V['kokoro_voice']}|{speed}|{seed}".encode()).hexdigest()[:10]
            name = f"{line['id']}-kokoro-s{speed:g}-r{seed}-{sig}.wav"
            path = takes_dir / name
            if not path.exists():
                if pipe is None:
                    print(f"Loading Kokoro-82M (voice {V['kokoro_voice']}) ...", flush=True)
                    pipe = KPipeline(lang_code=V["lang"], repo_id="hexgrad/Kokoro-82M")
                torch.manual_seed(seed)
                chunks = [audio for _, _, audio in pipe(line["say"], voice=V["kokoro_voice"], speed=speed)]
                wav = np.concatenate([c.cpu().numpy() if hasattr(c, "cpu") else np.asarray(c) for c in chunks])
                sf.write(path, wav, 24000, subtype="PCM_16")
            info = sf.info(path)
            manifest[name] = {"line": line["id"], "say": line["say"], "engine": "kokoro", "voice": V["kokoro_voice"],
                              "speed": speed, "seed": seed, "seconds": round(info.duration, 3)}
            print(f"  {name}  {info.duration:.2f}s", flush=True)
elif engine == "chatterbox":
    ref = V.get("reference")
    if not ref:
        sys.exit("voice.reference must point to a 10-15 s WAV of a voice you own (or have written permission to use)")
    ref_path = (reel / ref) if not Path(ref).is_absolute() else Path(ref)
    if not ref_path.exists():
        sys.exit(f"Reference WAV not found: {ref_path}")
    from chatterbox.tts import ChatterboxTTS  # noqa: E402  (optional env, see requirements-chatterbox.txt)
    device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    _load = torch.load  # checkpoints were saved on CUDA: map them onto this device when loading
    torch.load = lambda *a, **k: _load(*a, **{**k, "map_location": k.get("map_location", device)})
    model = None
    ref_hash = hashlib.sha256(ref_path.read_bytes()).hexdigest()[:12]
    for line in lines:
        for seed in seeds:
            sig = hashlib.sha256(f"chatterbox|{line['say']}|{ref_hash}|{V['exaggeration']}|{V['cfg']}|{V['temperature']}|{seed}".encode()).hexdigest()[:10]
            name = f"{line['id']}-chatterbox-r{seed}-{sig}.wav"
            path = takes_dir / name
            if not path.exists():
                if model is None:
                    print(f"Loading Chatterbox on {device} ...", flush=True)
                    model = ChatterboxTTS.from_pretrained(device=device)
                torch.manual_seed(seed)
                wav = model.generate(line["say"], audio_prompt_path=str(ref_path), exaggeration=V["exaggeration"],
                                     cfg_weight=V["cfg"], temperature=V["temperature"])
                sf.write(path, wav.squeeze().cpu().numpy(), model.sr, subtype="PCM_16")
            info = sf.info(path)
            manifest[name] = {"line": line["id"], "say": line["say"], "engine": "chatterbox", "reference_sha256_12": ref_hash,
                              "seed": seed, "seconds": round(info.duration, 3)}
            print(f"  {name}  {info.duration:.2f}s", flush=True)

common.save_json(manifest_path, manifest)
print(f"voice: {sum(1 for m in manifest.values() if m['line'] in {ln['id'] for ln in lines})} takes for {len(lines)} lines "
      f"in {time.time() - t_start:.1f}s -> {takes_dir}")
