"""Original music bed + sound effects, synthesized from numbers (no samples, no licenses to worry about).

- music.wav: a soft four-chord pad with a sub bass and a quiet plucked arpeggio, as long as the voiceover, levelled to
  sit `--music-db` LU under the voice before ducking (finish.sh also ducks it under the voice).
- sfx.wav: a whoosh before every line after the first, a pop on each `cues` action, a chime on "check" cues,
  levelled to sit `--sfx-db` LU under the voice.
Both are 48 kHz stereo and deterministic (same timeline in, same audio out).

Swap in your own licensed track instead: put it at <reel>/music.wav (48 kHz) and skip this step, or run with --no-music.

Usage: .venv/bin/python engine/sound.py example [--music-db 16] [--sfx-db 9] [--no-music] [--no-sfx]
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("reel")
ap.add_argument("--music-db", type=float, default=16.0, help="music loudness under the voice, in LU (default 16)")
ap.add_argument("--sfx-db", type=float, default=9.0, help="SFX loudness under the voice, in LU (default 9)")
ap.add_argument("--bpm", type=float, default=96.0)
ap.add_argument("--no-music", action="store_true")
ap.add_argument("--no-sfx", action="store_true")
args = ap.parse_args()

reel = common.reel_dir(args.reel)
S = common.load_script(reel)
tl_path = reel / "timeline.json"
if not tl_path.exists():
    sys.exit(f"No timeline.json: run engine/asr_gate.py {args.reel} first")
TL = json.loads(tl_path.read_text())
SR = 48000
N = int(round(TL["duration"] * SR))
tt = np.arange(N) / SR


def lufs(path: Path) -> float:
    err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(path), "-af", "ebur128", "-f", "null", "-"],
                         capture_output=True, text=True).stderr
    vals = re.findall(r"I:\s+(-?[\d.]+) LUFS", err)
    return float(vals[-1]) if vals else -70.0


def level(stereo: np.ndarray, path: Path, target: float) -> float:
    sf.write(path, stereo, SR, subtype="PCM_24")
    now = lufs(path)
    gain = 10 ** ((target - now) / 20) if now > -69 else 1.0
    out = np.clip(stereo * gain, -0.98, 0.98)
    sf.write(path, out, SR, subtype="PCM_24")
    return round(lufs(path), 2)


def resolve(at) -> float:
    """Same anchor grammar as scene.js: 2.5 | "line" | "line@end" | "line/word" | "line/word#2", optional " +0.2" (space before the sign)."""
    if isinstance(at, (int, float)):
        return float(at)
    m = re.fullmatch(r"\s*(\S+)(?:\s+([+-])\s*(\d*\.?\d+))?\s*", str(at))
    base, off = m.group(1), (float(m.group(3)) * (-1 if m.group(2) == "-" else 1) if m.group(2) else 0.0)
    if re.fullmatch(r"\d*\.?\d+", base):
        return float(base) + off
    edge = "end" if base.endswith("@end") else "start"
    base = base.split("@")[0]
    if "/" in base:
        lid, word = base.split("/", 1)
        n = int(word.split("#")[1]) - 1 if "#" in word else 0
        word = word.split("#")[0].lower()
        hits = [w for w in TL["words"] if w["line"] == lid and re.sub(r"[^a-z0-9]", "", w["text"].lower()) == word]
        if hits:
            return hits[min(n, len(hits) - 1)][edge] + off
        base = lid
    ln = next((x for x in TL["lines"] if x["id"] == base), None)
    if ln is None:
        print(f"warning: cue anchor '{at}' not found; using 0", file=sys.stderr)
        return off
    return ln[edge] + off


voice_lufs = lufs(reel / "voiceover.wav")
report = {"voice_lufs": voice_lufs}

# ---------------------------------------------------------------- music
if not args.no_music:
    beat = 60.0 / args.bpm
    bar = 4 * beat
    chords = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]  # Am F C G (MIDI)
    hz = lambda n: 440.0 * 2 ** ((n - 69) / 12)  # noqa: E731
    music = np.zeros((N, 2))
    chord_len = 2 * bar
    for k in range(int(np.ceil(TL["duration"] / chord_len)) + 1):
        c0 = k * chord_len
        notes = chords[k % len(chords)]
        a, b = int(max(0, c0 - 0.4) * SR), min(N, int((c0 + chord_len + 0.6) * SR))
        if a >= N:
            break
        seg = tt[a:b] - c0
        env = np.clip((seg + 0.4) / 0.8, 0, 1) * np.clip((chord_len + 0.6 - seg) / 0.8, 0, 1)
        for n in notes:
            for ch, det in ((0, -0.08), (1, 0.08)):
                f = hz(n + 12) * 2 ** (det / 12)
                tone = sum(np.sin(2 * np.pi * f * h * seg + h) / h ** 1.6 for h in range(1, 6))
                music[a:b, ch] += 0.05 * env * tone
        root = hz(notes[0] - 12)
        music[a:b] += (0.10 * env * np.sin(2 * np.pi * root * seg))[:, None]
        for step in range(16):  # eighth-note arpeggio over two bars
            s0 = c0 + step * beat / 2
            i0, i1 = int(s0 * SR), min(N, int((s0 + 0.35) * SR))
            if i0 >= N or i0 < 0:
                continue
            u = tt[i0:i1] - s0
            f = hz(notes[step % 3] + 24)
            pl = 0.035 * np.exp(-u * 9) * np.sin(2 * np.pi * f * u) * (0.6 + 0.4 * ((step % 4) == 0))
            pan = 0.5 + 0.3 * np.sin(step)
            music[i0:i1, 0] += pl * (1 - pan)
            music[i0:i1, 1] += pl * pan
    fade = np.clip((TL["duration"] - tt) / 1.0, 0, 1) * np.clip(tt / 0.05, 0, 1)
    music *= fade[:, None]
    report["music_lufs"] = level(music, reel / "music.wav", voice_lufs - args.music_db)

# ---------------------------------------------------------------- sfx
if not args.no_sfx:
    rng = np.random.default_rng(7)
    sfx = np.zeros((N, 2))

    def place(sig: np.ndarray, at: float, pan: float = 0.5):
        i0 = int(round(at * SR))
        if i0 >= N:
            return
        if i0 < 0:
            sig, i0 = sig[-i0:], 0
        i1 = min(N, i0 + len(sig))
        sfx[i0:i1, 0] += sig[: i1 - i0] * (1 - pan) * 2
        sfx[i0:i1, 1] += sig[: i1 - i0] * pan * 2

    def whoosh(dur=0.45):
        n = int(dur * SR)
        u = np.arange(n) / n
        noise = rng.standard_normal(n)
        out, y = np.zeros(n), 0.0
        for i in range(n):  # one-pole low-pass whose cutoff sweeps up then down
            fc = 300 + 5000 * np.sin(np.pi * u[i]) ** 2
            al = 1 - np.exp(-2 * np.pi * fc / SR)
            y += al * (noise[i] - y)
            out[i] = y
        return 0.6 * out * np.sin(np.pi * u) ** 2

    def pop(f0=900.0, f1=480.0, dur=0.09):
        u = np.arange(int(dur * SR)) / SR
        f = f0 + (f1 - f0) * u / dur
        return 0.5 * np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-u * 40)

    def chime():
        u = np.arange(int(0.7 * SR)) / SR
        return 0.25 * (np.sin(2 * np.pi * 1318.5 * u) + 0.7 * np.sin(2 * np.pi * 1975.5 * u)) * np.exp(-u * 6) * np.clip(u / 0.004, 0, 1)

    events = []
    for ln in TL["lines"][1:]:
        place(whoosh(), ln["start"] - 0.32)
        events.append(("whoosh", round(ln["start"] - 0.32, 3)))
    for cue in S.get("cues", []):
        at = resolve(cue["at"])
        kind = cue.get("do", "")
        if kind == "check":
            place(chime(), at)
        elif kind in ("wave", "jump", "spin", "nod", "point"):
            place(pop(), at + (0.12 if kind == "jump" else 0.0), pan=0.45)
        else:
            continue
        events.append((kind, round(at, 3)))
    report["sfx_lufs"] = level(sfx, reel / "sfx.wav", voice_lufs - args.sfx_db)
    report["sfx_events"] = events

common.save_json(reel / "sound.json", report)
print(json.dumps(report))
