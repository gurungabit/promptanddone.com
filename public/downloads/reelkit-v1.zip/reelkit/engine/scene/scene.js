// reelkit scene: an original voxel robot on a small floating island, one continuous camera, word-synced captions.
//
// THE RULE: draw(t) is a pure function of t (seconds). No Date.now(), performance.now() or Math.random() anywhere in
// the draw path: use hash(n) for "random" values. Then every frame renders the same way every time, and the renderer
// (engine/render.mjs) can step through the video frame by frame.
//
// Page API used by render.mjs: window.ready, window.sceneInfo, window.setTime(t), window.renderFrame(t, type, quality).
// URL: /engine/scene/index.html?reel=/example/   (add &render=1 for the headless renderer)
//
// To make your own reel's world: `make new SLUG=my-topic` copies this folder to reels/my-topic/scene/. Edit LOOK,
// buildWorld() and the camera KEYS; keep draw(t) pure.

import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {EffectComposer} from 'three/addons/postprocessing/EffectComposer.js';
import {RenderPass} from 'three/addons/postprocessing/RenderPass.js';
import {UnrealBloomPass} from 'three/addons/postprocessing/UnrealBloomPass.js';
import {OutputPass} from 'three/addons/postprocessing/OutputPass.js';

const W = 1080, H = 1920, FPS = 30;
const params = new URLSearchParams(location.search);
const REEL = (params.get('reel') || '/example/').replace(/\/?$/, '/');
const RENDER = params.has('render');
if (RENDER) document.body.classList.add('render');

// ------------------------------------------------------------------ look (edit these first)
const LOOK = {
  sky: ['#120c2e', '#3b2768', '#e98a6a'],      // top, middle, horizon
  fog: '#4a2f63',
  accent: '#ffd23f',                            // active caption word, chip, highlights
  robot: {shell: '#e4dac8', trim: '#2ec4b6', dark: '#1c2230', joint: '#7a8191', eye: '#8ff6ff', bulb: '#ff8a3d', cheek: '#ff9db5'},
  captionFont: '800 78px system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
  captionY: 1440,                               // caption centre; keep the hero above ~1380 and platform UI below 1600
  bloom: {strength: 0.45, radius: 0.5, threshold: 0.9},
};

// ------------------------------------------------------------------ deterministic helpers
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const smooth = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
const inout = (x) => { x = clamp(x); return x < .5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2; };
const back = (x, s = 1.7) => { x = clamp(x); return 1 + (s + 1) * Math.pow(x - 1, 3) + s * Math.pow(x - 1, 2); };
const hash = (n) => { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453; return s - Math.floor(s); };
const window01 = (t, a, b, fade = .2) => smooth((t - a) / fade) * (1 - smooth((t - b + fade) / fade));

// ------------------------------------------------------------------ data
const script = await fetch(REEL + 'script.json').then((r) => r.json());
let timeline = await fetch(REEL + 'timeline.json', {cache: 'no-store'}).then((r) => (r.ok ? r.json() : null)).catch(() => null);
const DRAFT = !timeline;
if (DRAFT) timeline = draftTimeline(script);       // estimated timing so you can build visuals before the voice exists
const DUR = timeline.duration;
const WORDS = timeline.words;
const style = script.style || {};
if (style.accent) LOOK.accent = style.accent;

function draftTimeline(s) {
  let t = 0; const words = [], lines = [];
  s.lines.forEach((ln, i) => {
    const id = ln.id || `line${i + 1}`, start = t;
    for (const w of ln.text.split(/\s+/)) { words.push({text: w, line: id, start: t, end: t + .3}); t += 1 / 2.8; }
    lines.push({id, text: ln.text, start, end: t}); t += .25;
  });
  return {duration: t + .8, fps: FPS, lines, words, draft: true};
}

// Anchors: 2.5 | "line" | "line@end" | "line/word" | "line/word#2", optional " +0.2" / " -0.1" (space before the sign).
function at(expr) {
  if (typeof expr === 'number') return expr;
  const m = String(expr).trim().match(/^(\S+)(?:\s+([+-])\s*(\d*\.?\d+))?$/);
  if (!m) return 0;
  const off = m[2] ? (m[2] === '-' ? -1 : 1) * parseFloat(m[3]) : 0;
  let base = m[1];
  if (/^\d*\.?\d+$/.test(base)) return parseFloat(base) + off;
  const edge = base.endsWith('@end') ? 'end' : 'start';
  base = base.split('@')[0];
  if (base.includes('/')) {
    const [lid, wordN] = base.split('/');
    const [word, n] = wordN.split('#');
    const norm = (x) => x.toLowerCase().replace(/[^a-z0-9]/g, '');
    const hits = WORDS.filter((w) => w.line === lid && norm(w.text) === norm(word));
    if (hits.length) return hits[Math.min((parseInt(n || '1', 10) - 1), hits.length - 1)][edge] + off;
    console.warn(`anchor word not found: ${expr}`);
    base = lid;
  }
  const ln = timeline.lines.find((l) => l.id === base);
  if (!ln) { console.warn(`anchor not found: ${expr}`); return off; }
  return ln[edge] + off;
}

const CUE_DUR = {wave: 1.4, jump: .8, spin: .9, nod: .7, point: 1.8, check: 1.9, push: 1.6};
const CUES = (script.cues || []).map((c) => ({do: c.do, t: at(c.at), dur: c.dur || CUE_DUR[c.do] || 1}));
const cue = (kind, t) => { // 0..1 progress through the active cue of this kind, or -1
  for (const c of CUES) if (c.do === kind && t >= c.t && t < c.t + c.dur) return (t - c.t) / c.dur;
  return -1;
};

// ------------------------------------------------------------------ renderer, scene, post
const out = document.getElementById('out');
const ctx = out.getContext('2d');
const renderer = new THREE.WebGLRenderer({antialias: true, powerPreference: 'high-performance'});
renderer.setPixelRatio(1);
renderer.setSize(W, H, false);
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, W / H, .1, 400);
const pmrem = new THREE.PMREMGenerator(renderer);
scene.environment = pmrem.fromScene(new RoomEnvironment(), .04).texture;
scene.environmentIntensity = .35;
scene.background = gradientTexture(LOOK.sky);
scene.fog = new THREE.Fog(LOOK.fog, 26, 95);

const composer = new EffectComposer(renderer);
composer.setPixelRatio(1);
composer.setSize(W, H);
composer.addPass(new RenderPass(scene, camera));
composer.addPass(new UnrealBloomPass(new THREE.Vector2(W, H), LOOK.bloom.strength, LOOK.bloom.radius, LOOK.bloom.threshold));
composer.addPass(new OutputPass());

function gradientTexture(stops) {
  const c = document.createElement('canvas'); c.width = 4; c.height = 512;
  const g = c.getContext('2d'), gr = g.createLinearGradient(0, 0, 0, 512);
  gr.addColorStop(0, stops[0]); gr.addColorStop(.55, stops[1]); gr.addColorStop(1, stops[2]);
  g.fillStyle = gr; g.fillRect(0, 0, 4, 512);
  const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; return tex;
}

// ------------------------------------------------------------------ voxel builder
const BOX = new RoundedBoxGeometry(1, 1, 1, 2, .12);
// list of {x, y, z, c, s?} in voxel units -> one InstancedMesh. glow: unlit, bright (blooms).
function voxels(list, size, {glow = false, rough = .78, cast = true, receive = true} = {}) {
  const mat = glow ? new THREE.MeshBasicMaterial({color: 0xffffff, toneMapped: false})
    : new THREE.MeshStandardMaterial({color: 0xffffff, roughness: rough, metalness: 0});
  const mesh = new THREE.InstancedMesh(BOX, mat, Math.max(1, list.length));
  const m = new THREE.Matrix4(), col = new THREE.Color();
  list.forEach((v, i) => {
    const s = size * (v.s || 1);
    m.makeScale(s * (v.sx || 1), s * (v.sy || 1), s * (v.sz || 1)); m.setPosition(v.x * size, v.y * size, v.z * size);
    mesh.setMatrixAt(i, m); mesh.setColorAt(i, col.set(v.c));
  });
  mesh.castShadow = cast && !glow; mesh.receiveShadow = receive && !glow;
  return mesh;
}
const fill = (list, x0, x1, y0, y1, z0, z1, c) => {
  for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++)
    list.push({x, y, z, c: typeof c === 'function' ? c(x, y, z) : c});
  return list;
};

// ------------------------------------------------------------------ the world
const world = buildWorld();
const robot = buildRobot();
robot.root.position.set(0, .25, .7);
scene.add(robot.root);

function buildWorld() {
  const S = .5, top = .25;                       // island voxel size; top surface height
  const W_ = {};
  // lights: soft sky fill, warm key with shadows, cool rim, practicals (lamp, screen, windows)
  scene.add(new THREE.HemisphereLight('#9fb7ff', '#5a3b2a', .55));
  const key = new THREE.DirectionalLight('#ffd9b0', 2.0);
  key.position.set(6, 11, 8); key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048); key.shadow.bias = -.0004; key.shadow.normalBias = .03;
  Object.assign(key.shadow.camera, {left: -9, right: 9, top: 9, bottom: -9, near: 1, far: 40});
  scene.add(key);
  const rim = new THREE.DirectionalLight('#8fa8ff', 1.3); rim.position.set(-7, 6, -10); scene.add(rim);

  // island: superellipse top, tapering rocky underside
  const island = [], shape = (x, z) => Math.pow(Math.abs(x / 8.6), 3.2) + Math.pow(Math.abs((z + 6) / 12.6), 3.2);
  const path = (z) => .8 * Math.sin(z * .28) - .3;
  for (let x = -9; x <= 9; x++) for (let z = -19; z <= 7; z++) {
    const d = shape(x, z);
    if (d > 1) continue;
    const onPath = Math.abs(x - path(z)) < 1.1 && z > -10 && z < 6;
    const water = Math.hypot(x - 5.2, z - 3.6) < 2.1;
    const grass = hash(x * 31 + z * 7) > .5 ? '#5fae4e' : '#6cbd57';
    island.push({x, y: water ? -.25 : 0, z, c: water ? '#2f7fd1' : onPath ? (hash(x + z * 13) > .5 ? '#b9b0a0' : '#a59c8c') : grass});
    for (let k = 1; k < 9; k++) {
      if (d > 1 - k * .115 + hash(x * 3 + z * 5 + k) * .1) break;
      island.push({x, y: -k, z, c: k === 1 ? '#7a5333' : k < 4 ? (hash(x + z + k) > .5 ? '#6b4528' : '#5e3c22') : '#55525a'});
    }
  }
  const islandMesh = voxels(island, S); scene.add(islandMesh);

  // pond surface + sparkles
  const pond = new THREE.Mesh(new THREE.CircleGeometry(1.05, 32),
    new THREE.MeshStandardMaterial({color: '#3d9cf0', roughness: .12, metalness: .2, transparent: true, opacity: .82}));
  pond.rotation.x = -Math.PI / 2; pond.position.set(5.2 * S, .14, 3.6 * S); pond.receiveShadow = true; scene.add(pond);
  W_.sparkles = voxels(Array.from({length: 10}, () => ({x: 0, y: 0, z: 0, c: '#dff6ff'})), .05, {glow: true}); scene.add(W_.sparkles);

  // trees
  const tree = (x, z, h, seed) => {
    const v = [];
    fill(v, 0, 0, 0, h, 0, 0, '#6e4a2e');
    const r = 2.2;
    for (let a = -3; a <= 3; a++) for (let b = -2; b <= 3; b++) for (let c = -3; c <= 3; c++) {
      const d = Math.hypot(a, (b - .5) * 1.15, c);
      if (d < r + hash(seed + a * 9 + b * 17 + c * 23) * .9) v.push({x: a, y: h + 1 + b, z: c, c: hash(seed + a + b * 3 + c * 7) > .5 ? '#3f9a4f' : '#4fb35a'});
    }
    const m = voxels(v, .3); m.position.set(x, top, z); scene.add(m); return m;
  };
  tree(-3.1, -3.2, 5, 1); tree(3.3, -6.8, 7, 2); tree(-2.6, -8.6, 8, 3); tree(-3.5, -.6, 4, 4);

  // lamp post (warm practical)
  const lamp = [];
  fill(lamp, 0, 0, 0, 8, 0, 0, '#3a3f4b'); lamp.push({x: 0, y: 9, z: 0, c: '#3a3f4b', s: 1.6, sy: .5});
  const lampMesh = voxels(lamp, .25); lampMesh.position.set(-2.3, top, 1.9); scene.add(lampMesh);
  W_.lampBulb = voxels([{x: 0, y: 0, z: 0, c: '#ffcf7a', s: 1}], .34, {glow: true});
  W_.lampBulb.position.set(-2.3, top + 2.08, 1.9); scene.add(W_.lampBulb);
  W_.lampLight = new THREE.PointLight('#ffb35c', 9, 9, 1.6); W_.lampLight.position.set(-2.3, top + 1.95, 2.1); scene.add(W_.lampLight);

  // monitor: the screen carrier (shows the script typing, or a real output image from script.screen.image)
  const mon = new THREE.Group(); mon.position.set(1.05, top, -2.1); mon.rotation.y = -.22; scene.add(mon);
  const frame = new THREE.Mesh(new RoundedBoxGeometry(3.3, 2.15, .18, 3, .06), new THREE.MeshStandardMaterial({color: '#232836', roughness: .5}));
  frame.position.y = 2.05; frame.castShadow = true; mon.add(frame);
  const legs = voxels([{x: -4, y: 0, z: 0, c: '#232836', sy: 4}, {x: 4, y: 0, z: 0, c: '#232836', sy: 4}], .25); legs.position.y = .5; mon.add(legs);
  W_.screenCanvas = document.createElement('canvas'); W_.screenCanvas.width = 1024; W_.screenCanvas.height = 640;
  W_.screenTex = new THREE.CanvasTexture(W_.screenCanvas); W_.screenTex.colorSpace = THREE.SRGBColorSpace; W_.screenTex.anisotropy = 4;
  const screen = new THREE.Mesh(new THREE.PlaneGeometry(3.08, 1.925), new THREE.MeshBasicMaterial({map: W_.screenTex, toneMapped: false, color: 0xe0e0e0}));  // just under the bloom threshold: crisp, no glow
  screen.position.set(0, 2.05, .095); mon.add(screen);
  const screenLight = new THREE.PointLight('#7fd8ff', 5, 6, 1.8); screenLight.position.set(0, 2, .9); mon.add(screenLight);

  // windmill with turning blades (a life loop)
  const mill = []; fill(mill, -1, 1, 0, 9, -1, 1, (x, y) => (y % 3 === 2 ? '#c8b89a' : '#e9dfc9'));
  fill(mill, -1, 1, 10, 10, -1, 1, '#b5523b');
  const millMesh = voxels(mill, .26); millMesh.position.set(-3.6, top, -6.4); scene.add(millMesh);
  W_.blades = new THREE.Group(); W_.blades.position.set(-3.6, top + 2.5, -6.0); scene.add(W_.blades);
  for (let i = 0; i < 4; i++) {
    const b = new THREE.Mesh(new RoundedBoxGeometry(.32, 1.5, .06, 2, .03), new THREE.MeshStandardMaterial({color: '#f4ecdc', roughness: .7}));
    b.geometry.translate(0, .8, 0); b.rotation.z = i * Math.PI / 2; b.castShadow = true; W_.blades.add(b);
  }

  // little cottage with lit windows (more practicals)
  const house = []; fill(house, -3, 3, 0, 4, -2, 2, (x, y, z) => (y === 0 ? '#9a8f84' : '#e7d8c0'));
  for (let y = 5; y <= 7; y++) fill(house, -4 + (y - 5), 4 - (y - 5), y, y, -3, 3, '#c0573f');
  const houseMesh = voxels(house, .3); houseMesh.position.set(3.4, top, -4.4); houseMesh.rotation.y = -.5; scene.add(houseMesh);
  const win = voxels([{x: -1.5, y: 2, z: 2.55, c: '#ffd27a', sx: 1.4, sy: 1.2, sz: .3}, {x: 1.5, y: 2, z: 2.55, c: '#ffd27a', sx: 1.4, sy: 1.2, sz: .3}], .3, {glow: true});
  win.position.copy(houseMesh.position); win.rotation.copy(houseMesh.rotation); scene.add(win);
  const houseLight = new THREE.PointLight('#ffc070', 4, 5, 1.8); houseLight.position.set(3.0, top + .8, -3.6); scene.add(houseLight);

  // flowers, mushrooms, rocks scattered by hash (deterministic)
  const deco = [];
  for (let i = 0; i < 70; i++) {
    const x = (hash(i * 3.1) - .5) * 15, z = (hash(i * 7.7) - .5) * 22 - 5;
    if (shape(x / S, z / S) > .8 || Math.abs(x / S - path(z / S)) < 1.6 || Math.hypot(x, z - .7) < 1.2) continue;
    if (Math.hypot(x - 2.6, z - 1.8) < 1.3 || Math.hypot(x - 1, z + 2.1) < 1.8) continue;
    const kind = hash(i * 1.3);
    if (kind < .62) {
      deco.push({x: x / .12, y: (top + .06) / .12, z: z / .12, c: '#3d8a3f', sy: 1.6});
      deco.push({x: x / .12, y: (top + .2) / .12, z: z / .12, c: ['#ff7aa8', '#ffe066', '#ffffff', '#b98cff'][i % 4], s: 1.2});
    } else if (kind < .78) {
      deco.push({x: x / .12, y: (top + .1) / .12, z: z / .12, c: '#f3ead9', sy: 2});
      deco.push({x: x / .12, y: (top + .28) / .12, z: z / .12, c: '#e0483e', s: 2.6, sy: 1.1});
    } else {
      deco.push({x: x / .12, y: (top + .1) / .12, z: z / .12, c: hash(i) > .5 ? '#8d8a93' : '#77737c', s: 2.4 + hash(i * 5) * 2, sy: 1.4});
    }
  }
  scene.add(voxels(deco, .12));

  // fireflies (glowing, orbit on fixed paths)
  W_.flies = voxels(Array.from({length: 28}, () => ({x: 0, y: 0, z: 0, c: '#fff3a0'})), .06, {glow: true}); scene.add(W_.flies);

  // far layer: floating mini islands, clouds, stars, a low sun
  W_.far = [];
  [[-11, 3, -34, 1.2], [12, 6, -42, 1.6], [-4, 9, -55, 1.1], [7, -2, -26, .8]].forEach(([x, y, z, sc], i) => {
    const v = [];
    for (let a = -4; a <= 4; a++) for (let c = -3; c <= 3; c++) {
      if (a * a / 16 + c * c / 9 > 1) continue;
      v.push({x: a, y: 0, z: c, c: '#6cbd57'});
      for (let k = 1; k < 4 && a * a / 16 + c * c / 9 < 1 - k * .3; k++) v.push({x: a, y: -k, z: c, c: '#5e3c22'});
    }
    fill(v, 1, 1, 1, 3, 0, 0, '#6e4a2e'); fill(v, 0, 2, 4, 5, -1, 1, '#3f9a4f');
    const m = voxels(v, .5 * sc, {cast: false}); m.position.set(x, y, z); m.userData.seed = i; scene.add(m); W_.far.push(m);
  });
  W_.clouds = [];
  for (let i = 0; i < 7; i++) {
    const v = [];
    for (let a = -3; a <= 3; a++) for (let b = 0; b <= 2; b++) for (let c = -1; c <= 1; c++)
      if (hash(i * 50 + a * 7 + b * 13 + c * 3) > .3 + b * .2) v.push({x: a, y: b, z: c, c: '#f6eef6'});
    const m = voxels(v, .7, {cast: false, rough: .95});
    m.position.set((hash(i * 4.1) - .5) * 40, 6 + hash(i * 2.3) * 9, -22 - hash(i * 9.2) * 30);
    m.userData.x0 = m.position.x; scene.add(m); W_.clouds.push(m);
  }
  const starPos = [];
  for (let i = 0; i < 500; i++) {
    const az = hash(i * 1.7) * Math.PI * 2, el = .12 + hash(i * 3.3) * 1.2;
    starPos.push(Math.cos(az) * Math.cos(el) * 150, Math.sin(el) * 150, Math.sin(az) * Math.cos(el) * 150 - 40);
  }
  const stars = new THREE.Points(new THREE.BufferGeometry().setAttribute('position', new THREE.Float32BufferAttribute(starPos, 3)),
    new THREE.PointsMaterial({color: '#ffffff', size: 2, sizeAttenuation: false, fog: false, transparent: true, opacity: .8}));
  scene.add(stars);
  const sunC = document.createElement('canvas'); sunC.width = sunC.height = 256;
  const sg = sunC.getContext('2d'), sgr = sg.createRadialGradient(128, 128, 0, 128, 128, 128);
  sgr.addColorStop(0, 'rgba(255,214,160,1)'); sgr.addColorStop(.25, 'rgba(255,170,120,.55)'); sgr.addColorStop(1, 'rgba(255,140,110,0)');
  sg.fillStyle = sgr; sg.fillRect(0, 0, 256, 256);
  const sunTex = new THREE.CanvasTexture(sunC); sunTex.colorSpace = THREE.SRGBColorSpace;
  const sun = new THREE.Sprite(new THREE.SpriteMaterial({map: sunTex, fog: false, depthWrite: false, transparent: true}));
  sun.scale.set(70, 70, 1); sun.position.set(-14, 4, -110); scene.add(sun);
  return W_;
}

// ------------------------------------------------------------------ the robot (original design)
function buildRobot() {
  const R = .11, C = LOOK.robot, root = new THREE.Group(), body = new THREE.Group();
  root.add(body);
  const shell = [];
  fill(shell, -2, -1, 0, 3, -1, 0, C.joint); fill(shell, 1, 2, 0, 3, -1, 0, C.joint);          // legs
  fill(shell, -2, -1, 0, 0, -1, 1, C.dark); fill(shell, 1, 2, 0, 0, -1, 1, C.dark);              // feet
  fill(shell, -3, 3, 4, 9, -2, 2, (x, y, z) => (z === 2 && Math.abs(x) <= 1 && y >= 5 && y <= 6 ? C.trim : y === 4 ? C.trim : C.shell));
  body.add(voxels(shell, R));
  const heart = voxels([{x: 0, y: 7.6, z: 2.55, c: C.bulb, s: 1.1}], R, {glow: true}); body.add(heart);
  const arm = (side) => {
    const g = new THREE.Group(); g.position.set(side * 3.9 * R, 8.6 * R, 0);
    const v = fill([], 0, 0, -4, 0, -1, 0, C.shell); fill(v, 0, 0, -6, -5, -1, 0, C.joint); v.push({x: 0, y: .3, z: -.5, c: C.trim, s: 1.25});
    const m = voxels(v, R); m.position.x = side * .5 * R; g.add(m); body.add(g); return g;
  };
  const armL = arm(-1), armR = arm(1);
  const head = new THREE.Group(); head.position.set(0, 10 * R, 0); body.add(head);
  const hv = fill([], -4, 4, 0, 6, -3, 3, (x, y, z) => (z === 3 && Math.abs(x) <= 3 && y >= 2 && y <= 4 ? C.dark : C.shell));
  fill(hv, -5, -5, 2, 4, -1, 0, C.trim); fill(hv, 5, 5, 2, 4, -1, 0, C.trim);                   // ear bolts
  hv.push({x: -3, y: 1, z: 3.3, c: C.cheek, sy: .6, sz: .5}, {x: 3, y: 1, z: 3.3, c: C.cheek, sy: .6, sz: .5});
  fill(hv, 0, 0, 7, 8, 0, 0, C.joint);                                                             // antenna stalk
  head.add(voxels(hv, R));
  const eyes = new THREE.Group(); eyes.position.set(0, 3 * R, 3.55 * R); head.add(eyes);
  eyes.add(voxels([{x: -1.6, y: 0, z: 0, c: C.eye, sx: 1.4, sy: 1.6, sz: .3}, {x: 1.6, y: 0, z: 0, c: C.eye, sx: 1.4, sy: 1.6, sz: .3}], R, {glow: true}));
  const bulb = voxels([{x: 0, y: 0, z: 0, c: C.bulb, s: 1}], R * 2, {glow: true}); bulb.position.set(0, 9.8 * R, 0); head.add(bulb);
  const bulbLight = new THREE.PointLight(C.bulb, 1.5, 3, 2); bulbLight.position.set(0, 10.5 * R, .3); head.add(bulbLight);
  // the "check" stamp that pops above the head
  const check = new THREE.Group(); check.position.set(0, 2.8, .1); root.add(check);
  const cv = [[0, 2], [1, 1], [2, 0], [3, 1], [4, 2], [5, 3], [6, 4], [7, 5]].map(([x, y]) => ({x: x - 3.5, y: y - 2.5, z: 0, c: '#5dff8a', s: 1.15}));
  check.add(voxels(cv, .13, {glow: true}));
  return {root, body, head, armL, armR, eyes, bulb, bulbLight, heart, check};
}

// ------------------------------------------------------------------ screen (redrawn only when its visible state changes)
let screenKey = '', screenImg = null;
if (script.screen?.image) {
  screenImg = new Image(); screenImg.src = REEL + script.screen.image;
  await screenImg.decode().catch(() => { console.warn('screen image failed to load'); screenImg = null; });
}
function drawScreen(t) {
  const shown = WORDS.filter((w) => w.start <= t).length, cursor = Math.floor(t * 2.2) % 2;
  const key = screenImg ? 'img' : `${shown}|${cursor}`;
  if (key === screenKey) return;
  screenKey = key;
  const c = world.screenCanvas, g = c.getContext('2d');
  g.fillStyle = '#0e1320'; g.fillRect(0, 0, c.width, c.height);
  if (screenImg) {
    const k = Math.max(c.width / screenImg.width, c.height / screenImg.height);
    g.drawImage(screenImg, (c.width - screenImg.width * k) / 2, (c.height - screenImg.height * k) / 2, screenImg.width * k, screenImg.height * k);
    if (script.screen.label) chip(g, script.screen.label.toUpperCase(), 30, 30, 44);
  } else {
    g.fillStyle = '#1a2133'; g.fillRect(0, 0, c.width, 64);
    ['#ff6b6b', '#ffd23f', '#5dff8a'].forEach((col, i) => { g.fillStyle = col; g.beginPath(); g.arc(40 + i * 34, 32, 10, 0, 7); g.fill(); });
    g.fillStyle = '#8b95ad'; g.font = '600 28px ui-monospace, Menlo, Consolas, monospace'; g.fillText('script.json', 160, 42);
    g.font = '600 34px ui-monospace, Menlo, Consolas, monospace';
    const y = 120, rows = [];
    for (const ln of timeline.lines) {
      const ws = WORDS.filter((w) => w.line === ln.id);
      const vis = ws.filter((w) => w.start <= t);
      if (!vis.length) break;
      let row = '';
      for (const w of vis) {
        const next = row ? row + ' ' + w.text : w.text;
        if (g.measureText(next).width > 920) { rows.push({text: row}); row = w.text; } else row = next;
      }
      rows.push({text: row});
    }
    const visRows = rows.slice(-11);
    visRows.forEach((r, i) => {
      g.fillStyle = i === visRows.length - 1 ? '#ffffff' : '#9aa6c2';
      g.fillText(r.text, 50, y + i * 46);
      if (i === visRows.length - 1 && cursor) { g.fillStyle = LOOK.accent; g.fillRect(56 + g.measureText(r.text).width, y + i * 46 - 30, 18, 36); }
    });
    if (!rows.length && cursor) { g.fillStyle = LOOK.accent; g.fillRect(50, y - 30, 18, 36); }
  }
  world.screenTex.needsUpdate = true;
}

// ------------------------------------------------------------------ camera: one continuous path (u = t / duration)
const KEYS = [  // [u, position, look-at, fov]
  [0.00, [0.8, 1.6, 8.0], [0.15, 1.05, 0.3], 34],   // hook: the robot full-height, screen glowing behind
  [0.30, [2.6, 2.4, 9.4], [0.3, 1.0, -0.8], 38],     // pull back: the island appears
  [0.62, [-2.8, 3.2, 9.8], [0.2, 0.9, -1.6], 40],    // drift left and up: the whole world
  [1.00, [-0.9, 1.7, 8.2], [0.15, 1.05, 0.0], 34],   // come back round for the ending
];
const camPos = new THREE.CatmullRomCurve3(KEYS.map((k) => new THREE.Vector3(...k[1])), false, 'centripetal');
const camLook = new THREE.CatmullRomCurve3(KEYS.map((k) => new THREE.Vector3(...k[2])), false, 'centripetal');
const tmpA = new THREE.Vector3(), tmpB = new THREE.Vector3();
function cameraAt(t) {
  const u = clamp(t / DUR);
  // map time u to curve parameter so each key is reached at its u, with smooth in/out between keys
  let i = 0; while (i < KEYS.length - 2 && u > KEYS[i + 1][0]) i++;
  const k = (u - KEYS[i][0]) / (KEYS[i + 1][0] - KEYS[i][0]);
  const e = lerp(k, inout(k), .55);              // part linear so the camera never parks
  const p = (i + e) / (KEYS.length - 1);
  camPos.getPoint(p, tmpA); camLook.getPoint(p, tmpB);
  camera.fov = lerp(KEYS[i][3], KEYS[i + 1][3], inout(k));
  const push = cue('push', t);                    // "push" cue: a quick dolly toward the subject
  if (push >= 0) tmpA.lerp(tmpB, .12 * Math.sin(Math.PI * push));
  tmpA.x += .05 * Math.sin(t * .7) + .025 * Math.sin(t * 1.9 + 1);  // gentle handheld drift (deterministic)
  tmpA.y += .035 * Math.sin(t * .9 + 2);
  camera.position.copy(tmpA); camera.lookAt(tmpB); camera.updateProjectionMatrix();
}

// ------------------------------------------------------------------ animation state at time t
const M4 = new THREE.Matrix4(), SC = new THREE.Matrix4();
function speaking(t) {   // 0..1 envelope while a word is being said
  for (const w of WORDS) if (t >= w.start && t <= w.end + .02) return Math.sin(Math.PI * clamp((t - w.start) / Math.max(.08, w.end - w.start)));
  return 0;
}
function animate(t) {
  const r = robot, talk = speaking(t);
  // body: idle bob + talking bounce
  let y = .025 * Math.sin(t * 2 * Math.PI * .8), sq = 1 + .02 * Math.sin(t * 2 * Math.PI * .8 + 1) + .025 * talk, spin = 0;
  let headPitch = .05 * Math.sin(t * 1.3) - .06 * talk, headYaw = .12 * Math.sin(t * .6), bodyYaw = 0;
  let armL = -.12 - .05 * Math.sin(t * 1.7), armR = .12 + .05 * Math.sin(t * 1.7 + .5);
  const j = cue('jump', t);
  if (j >= 0) {   // anticipation squash -> hop with stretch -> land squash -> settle
    if (j < .18) sq *= 1 - .16 * smooth(j / .18);
    else if (j < .7) { const h = (j - .18) / .52; y += .75 * 4 * h * (1 - h); sq *= 1.07 - .07 * Math.abs(1 - 2 * h); }
    else sq *= 1 - .12 * Math.sin(Math.PI * clamp((j - .7) / .3)) * (1 - (j - .7) / .3);
    armL -= .9 * Math.sin(Math.PI * j); armR += .9 * Math.sin(Math.PI * j);
  }
  const w = cue('wave', t);
  if (w >= 0) { const env = window01(w, 0, 1, .2); armR = lerp(armR, 2.55 + .35 * Math.sin(w * Math.PI * 5), env); headYaw += .15 * env; }
  const s = cue('spin', t);
  if (s >= 0) { spin = Math.PI * 2 * inout(s); y += .18 * Math.sin(Math.PI * s); }
  const n = cue('nod', t);
  if (n >= 0) headPitch += .28 * Math.sin(n * Math.PI * 2) * (1 - n);
  const p = cue('point', t);
  if (p >= 0) { const env = window01(p, 0, 1, .18); armR = lerp(armR, 1.3, env); bodyYaw = .35 * env; headYaw += .35 * env; }  // present the screen
  r.root.position.y = .25 + y;
  r.root.rotation.y = spin + bodyYaw;
  r.body.scale.set(1 / Math.sqrt(sq), sq, 1 / Math.sqrt(sq));
  r.head.rotation.set(headPitch, headYaw, .03 * Math.sin(t * .9));
  r.armL.rotation.set(0, 0, armL); r.armR.rotation.set(0, 0, armR);
  // eyes blink on a fixed schedule; antenna bulb and chest light pulse while talking
  const bl = ((t + .4) % 3.3) / 3.3;
  r.eyes.scale.y = bl < .035 ? .15 : 1;
  const pulse = .7 + .5 * talk;
  r.bulb.scale.setScalar(.9 + .25 * talk); r.bulbLight.intensity = 1 + 2.5 * talk; r.heart.scale.setScalar(pulse);
  // check stamp
  const c = cue('check', t);
  const cs = c < 0 ? 0 : c < .15 ? back(c / .15) : c > .88 ? 1 - smooth((c - .88) / .12) : 1;
  r.check.scale.setScalar(Math.max(.0001, cs)); r.check.rotation.y = .4 * Math.sin(t * 2);
  r.check.position.y = 2.8 + .06 * Math.sin(t * 3);

  // life loops: windmill, fireflies, pond sparkles, clouds, far islands, lamp flicker
  world.blades.rotation.z = -t * 1.3;
  for (let i = 0; i < 28; i++) {
    const a = hash(i * 9.1) * 6.28 + t * (.25 + hash(i) * .35), rad = 2 + hash(i * 4.4) * 4;
    M4.makeTranslation(Math.cos(a) * rad, .6 + hash(i * 2.2) * 2.4 + .25 * Math.sin(t * 1.4 + i), -2.5 + Math.sin(a * 1.3) * rad * .9);
    world.flies.setMatrixAt(i, M4.multiply(SC.makeScale(.06, .06, .06)));
  }
  world.flies.instanceMatrix.needsUpdate = true;
  for (let i = 0; i < 10; i++) {
    const ph = (t * .9 + hash(i * 3.7)) % 1, sc = .05 * Math.sin(Math.PI * ph);
    M4.makeTranslation(2.6 + (hash(i * 5.3) - .5) * 1.6, .1, 1.8 + (hash(i * 8.1) - .5) * 1.4);
    world.sparkles.setMatrixAt(i, M4.multiply(SC.makeScale(sc, sc * .4, sc)));
  }
  world.sparkles.instanceMatrix.needsUpdate = true;
  world.clouds.forEach((m, i) => { m.position.x = m.userData.x0 + t * (.12 + hash(i) * .1); });
  world.far.forEach((m, i) => { m.rotation.y = .05 * Math.sin(t * .3 + i); });
  world.lampLight.intensity = 9 * (1 + .04 * Math.sin(t * 7.3) + .03 * Math.sin(t * 13.1));
}

// ------------------------------------------------------------------ captions (max N words, active word highlighted)
function buildCaptions(words, maxWords) {
  const caps = []; let batch = [], last = null;
  const push = () => { if (batch.length) { caps.push({start: batch[0].start, end: batch.at(-1).end, words: batch}); batch = []; } };
  words.forEach((w, i) => {
    if (last && w.line !== last) push();
    last = w.line; batch.push(w);
    const endP = /[.,!?;:…]$/.test(w.text), nx = words[i + 1];
    const orphan = nx && nx.line === w.line && /[.,!?;:]$/.test(nx.text) && !endP && batch.length === maxWords;  // don't strand one word
    if ((batch.length >= maxWords && !orphan) || (endP && batch.length >= 2) || /[.!?]$/.test(w.text) || batch.length > maxWords) push();
  });
  push();
  caps.forEach((c, i) => { const n = caps[i + 1]; c.until = n ? Math.min(n.start, c.end + .45) : c.end + 1.0; });
  return caps;
}
const CAPS = buildCaptions(WORDS, (script.captions && script.captions.max_words) || 4);
function roundRect(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }
function chip(g, text, x, y, size) {
  g.font = `800 ${size}px system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif`;
  const w = g.measureText(text).width + size * 1.1;
  g.fillStyle = LOOK.accent; roundRect(g, x, y, w, size * 1.7, size * .85); g.fill();
  g.fillStyle = '#16120a'; g.textBaseline = 'middle'; g.fillText(text, x + size * .55, y + size * .87); g.textBaseline = 'alphabetic';
}
function drawCaptions(g, t) {
  const cap = CAPS.findLast((c) => c.start <= t + .001 && t < c.until);
  if (!cap) return;
  g.save();
  let size = 78; g.font = LOOK.captionFont.replace('78px', `${size}px`);
  const space = () => g.measureText(' ').width + size * .1;
  let widths = cap.words.map((w) => g.measureText(w.text).width);
  let total = widths.reduce((a, b) => a + b, 0) + space() * (cap.words.length - 1);
  if (total > 940) { size = Math.floor(size * 940 / total); g.font = LOOK.captionFont.replace('78px', `${size}px`); widths = cap.words.map((w) => g.measureText(w.text).width); total = widths.reduce((a, b) => a + b, 0) + space() * (cap.words.length - 1); }
  const first = cap.start < 1 / FPS;  // the hook caption is fully formed on frame 0
  const k = first ? 1 : clamp((t - cap.start) / .12), pop = lerp(.9, 1, back(k)), alpha = first ? 1 : clamp((t - cap.start) / .07 + .35);
  g.translate(W / 2, LOOK.captionY); g.scale(pop, pop); g.globalAlpha = alpha;
  g.textBaseline = 'middle'; g.lineJoin = 'round';
  let x = -total / 2;
  cap.words.forEach((w, i) => {
    const next = cap.words[i + 1];
    const active = t >= w.start && t < (next ? next.start : cap.until);
    if (active) { g.fillStyle = LOOK.accent; roundRect(g, x - 14, -size * .62, widths[i] + 28, size * 1.24, size * .28); g.fill(); }
    g.lineWidth = size * .16; g.strokeStyle = 'rgba(8,8,14,.9)';
    if (!active) g.strokeText(w.text, x, 0);
    g.fillStyle = active ? '#14110a' : '#ffffff'; g.fillText(w.text, x, 0);
    x += widths[i] + space();
  });
  g.restore();
}

// ------------------------------------------------------------------ draw(t): the only entry point for a frame
const vignette = (() => {
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'), gr = g.createRadialGradient(W / 2, H * .45, H * .25, W / 2, H * .5, H * .75);
  gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,.5)'); g.fillStyle = gr; g.fillRect(0, 0, W, H); return c;
})();
function draw(t) {
  t = clamp(t, 0, DUR);
  animate(t);
  drawScreen(t);
  cameraAt(t);
  composer.render();
  ctx.drawImage(renderer.domElement, 0, 0, W, H);
  ctx.drawImage(vignette, 0, 0);
  if (script.kicker) chip(ctx, script.kicker.toUpperCase(), 64, 250, 34);
  if (DRAFT && !RENDER) chip(ctx, 'DRAFT TIMING (no timeline.json yet)', 64, 330, 26);
  drawCaptions(ctx, t);
}

// ------------------------------------------------------------------ page API + preview player
const frames = Math.ceil(DUR * FPS);
window.sceneInfo = {duration: DUR, fps: FPS, frames, draft: DRAFT, reel: REEL, cues: CUES};
window.setTime = (t) => { draw(t); return t; };
window.renderFrame = (t, type = 'image/jpeg', quality = .93) => { draw(t); return out.toDataURL(type, quality); };
draw(0);

if (!RENDER) {
  const play = document.getElementById('play'), seek = document.getElementById('seek'), clock = document.getElementById('clock');
  seek.max = DUR;
  document.getElementById('note').textContent = DRAFT ? 'draft timing' : `${DUR.toFixed(2)} s`;
  const audio = new Audio(REEL + 'voiceover.wav');
  let playing = false, t0 = 0, wall0 = 0, hasAudio = true;
  audio.onerror = () => { hasAudio = false; };
  const now = () => (hasAudio ? audio.currentTime : t0 + (performance.now() - wall0) / 1000); // preview only, never in draw
  const tick = () => {
    if (!playing) return;
    const t = now();
    if (t >= DUR) { playing = false; play.textContent = 'Play'; audio.pause(); draw(DUR); return; }
    draw(t); seek.value = t; clock.textContent = t.toFixed(2);
    requestAnimationFrame(tick);
  };
  play.onclick = () => {
    playing = !playing; play.textContent = playing ? 'Pause' : 'Play';
    if (playing) { t0 = +seek.value >= DUR ? 0 : +seek.value; wall0 = performance.now(); if (hasAudio) { audio.currentTime = t0; audio.play().catch(() => { hasAudio = false; }); } tick(); }
    else audio.pause();
  };
  seek.oninput = () => { playing = false; play.textContent = 'Play'; audio.pause(); draw(+seek.value); clock.textContent = (+seek.value).toFixed(2); };
  addEventListener('keydown', (e) => { if (e.code === 'Space') { e.preventDefault(); play.click(); } });
}
window.ready = true;
