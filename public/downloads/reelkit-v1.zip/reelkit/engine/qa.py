"""Automated QA on the ENCODED file (what viewers get), as pass/fail checks.

Checks: resolution 1080x1920, H.264 High yuv420p, 30 fps, AAC 48 kHz stereo, fast-start, duration (in range and equal
to the timeline), loudness -14 LUFS +/- 1, true peak <= -1.5 dBTP, frame 0 not black or blank, no one-frame flashes
(whole-frame and per-region luma spikes), hard cuts <= qa.max_cuts, speech starts within 0.3 s, and Whisper on the
final audio says exactly the script (plus caption timing drift). Also writes contact-sheet.jpg (2 frames per second)
for a human or Claude to LOOK at: automated checks do not judge taste, framing or overlaps.

Writes <reel>/qa.json and prints one line per check. Exit code 1 if anything fails.

Usage: .venv/bin/python engine/qa.py example [--video example/final.mp4] [--model small.en]
"""
from __future__ import annotations

import argparse
import difflib
import json
import struct
import subprocess
import sys
import time
from fractions import Fraction
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import common  # noqa: E402

ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
ap.add_argument("reel")
ap.add_argument("--video", help="default <reel>/final.mp4")
ap.add_argument("--model", help="faster-whisper model for the final-audio check (default asr.model)")
ap.add_argument("--skip-asr", action="store_true")
args = ap.parse_args()

t_start = time.time()
reel = common.reel_dir(args.reel)
S = common.load_script(reel)
QA = {"min_seconds": 5, "max_seconds": 90, "max_cuts": 2, **S.get("qa", {})}
video = Path(args.video).resolve() if args.video else reel / "final.mp4"
if not video.exists():
    sys.exit(f"missing {video}: run engine/finish.sh first")
TL = json.loads((reel / "timeline.json").read_text())
checks = []


def check(name, ok, value, want):
    checks.append({"check": name, "pass": bool(ok), "value": value, "want": want})


def run(cmd):
    return subprocess.run(cmd, capture_output=True, check=True)


# ---------------------------------------------------------------- container + streams
probe = json.loads(run(["ffprobe", "-v", "error", "-show_streams", "-show_format", "-of", "json", str(video)]).stdout)
v = next(s for s in probe["streams"] if s["codec_type"] == "video")
a = next((s for s in probe["streams"] if s["codec_type"] == "audio"), {})
dur = float(probe["format"]["duration"])
check("resolution", (v["width"], v["height"]) == (1080, 1920), f"{v['width']}x{v['height']}", "1080x1920")
check("video_codec", (v["codec_name"], v.get("profile"), v["pix_fmt"]) == ("h264", "High", "yuv420p"),
      f"{v['codec_name']} {v.get('profile')} {v['pix_fmt']}", "h264 High yuv420p")
check("frame_rate", Fraction(v["avg_frame_rate"]) == 30 and Fraction(v["r_frame_rate"]) == 30, v["avg_frame_rate"], "30/1")
check("audio", (a.get("codec_name"), a.get("sample_rate"), a.get("channels")) == ("aac", "48000", 2),
      f"{a.get('codec_name')} {a.get('sample_rate')} Hz {a.get('channels')} ch", "aac 48000 Hz 2 ch")


def moov_first(path: Path) -> bool:
    with open(path, "rb") as f:
        while True:
            head = f.read(8)
            if len(head) < 8:
                return False
            size, kind = struct.unpack(">I4s", head)
            if kind == b"moov":
                return True
            if kind == b"mdat":
                return False
            if size == 1:
                size = struct.unpack(">Q", f.read(8))[0] - 8
            elif size == 0:
                return False
            f.seek(size - 8, 1)


check("faststart", moov_first(video), "moov before mdat" if moov_first(video) else "moov after mdat", "moov before mdat")
check("duration_range", QA["min_seconds"] <= dur <= QA["max_seconds"], round(dur, 3), f"{QA['min_seconds']}-{QA['max_seconds']} s")
check("duration_matches_timeline", abs(dur - TL["duration"]) <= 1 / 30 + .05, f"{dur:.3f} vs {TL['duration']:.3f}", "within 0.09 s")

# ---------------------------------------------------------------- loudness
err = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(video), "-map", "0:a:0", "-af", "ebur128=peak=true",
                      "-f", "null", "-"], capture_output=True, text=True).stderr
summary = err[err.rfind("Summary:"):]
lufs = float(summary.split("I:")[1].split("LUFS")[0])
tp = float(summary.split("Peak:")[1].split("dBFS")[0])
check("loudness", -15 <= lufs <= -13, f"{lufs:.1f} LUFS", "-14 +/- 1 LUFS")
check("true_peak", tp <= -1.5, f"{tp:.2f} dBTP", "<= -1.5 dBTP")

# ---------------------------------------------------------------- pictures: first frame, flashes, cuts
w, h = 72, 128
raw = run(["ffmpeg", "-v", "error", "-i", str(video), "-vf", f"scale={w}:{h}:flags=area,format=gray", "-f", "rawvideo", "-"]).stdout
fr = np.frombuffer(raw, np.uint8).reshape(-1, h, w).astype(np.float32)
check("frame_count", abs(len(fr) - round(dur * 30)) <= 1, len(fr), f"{round(dur * 30)} (duration x 30)")
f0 = fr[0]
check("first_frame_not_blank", f0.mean() >= 18 and f0.std() >= 8, f"mean {f0.mean():.1f}, std {f0.std():.1f}", "mean >= 18 and std >= 8 (0-255)")
g = fr.mean(axis=(1, 2))
cells = fr.reshape(len(fr), 4, h // 4, 4, w // 4).mean(axis=(2, 4)).reshape(len(fr), 16)


def spikes(x: np.ndarray, th: float) -> np.ndarray:
    """frames that jump away from BOTH neighbours in the same direction while the neighbours agree (one-frame flash)"""
    if len(x) < 3:
        return np.zeros(0, int)
    d1, d2, nb = x[1:-1] - x[:-2], x[1:-1] - x[2:], np.abs(x[:-2] - x[2:])
    hit = (np.abs(d1) > th) & (np.abs(d2) > th) & (np.sign(d1) == np.sign(d2)) & (nb < th / 2)
    return np.flatnonzero(hit.any(axis=1) if hit.ndim > 1 else hit) + 1


flash = sorted(set(spikes(g, 3.0).tolist()) | set(spikes(cells, 12.0).tolist()))
check("no_one_frame_flashes", not flash, [f"frame {i} ({i / 30:.2f}s)" for i in flash][:10], "none")
sc = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(video), "-vf", "select='gt(scene,0.3)',showinfo", "-f", "null", "-"],
                    capture_output=True, text=True).stderr
cuts = [float(x.split("pts_time:")[1].split()[0]) for x in sc.splitlines() if "pts_time:" in x]
check("hard_cuts", len(cuts) <= QA["max_cuts"], [round(c, 2) for c in cuts], f"<= {QA['max_cuts']}")
first_word = TL["words"][0]["start"]
check("speech_starts_early", first_word <= 0.3, f"{first_word:.2f}s", "<= 0.30 s (hook: no silent intro)")

# ---------------------------------------------------------------- final-audio ASR vs the script
if not args.skip_asr:
    from faster_whisper import WhisperModel  # noqa: E402
    wav = reel / ".work" / "qa-audio.wav"
    wav.parent.mkdir(exist_ok=True)
    run(["ffmpeg", "-v", "error", "-y", "-i", str(video), "-vn", "-ac", "1", "-ar", "16000", str(wav)])
    model_name = args.model or S["asr"]["model"]
    model = WhisperModel(model_name, device="cpu", compute_type="int8")
    segs, _ = model.transcribe(str(wav), language="en" if model_name.endswith(".en") else None, beam_size=5,
                               word_timestamps=True, condition_on_previous_text=False, initial_prompt=S["asr"]["prompt"] or None)
    heard = [{"text": x.word.strip(), "start": x.start, "end": x.end} for s in segs for x in s.words]
    got = [t["tok"] for t in common.expand_words(heard, S["token_map"])]
    want = common.tokens(" ".join(ln["say"] for ln in S["lines"]), S["token_map"])
    diff = [d for d in difflib.ndiff(want, got) if d[0] in "+-"]
    check("final_audio_matches_script", not diff, " ".join(x["text"] for x in heard) if diff else "exact match", "exact word match")
    cap = [common.tokens(x["text"], S["token_map"])[:1] for x in TL["words"]]
    capw = [c[0] if c else "" for c in cap]
    hw = [common.tokens(x["text"], S["token_map"])[:1] for x in heard]
    hw = [c[0] if c else "" for c in hw]
    sm = difflib.SequenceMatcher(a=capw, b=hw, autojunk=False)
    off = [heard[b.b + k]["start"] - TL["words"][b.a + k]["start"] for b in sm.get_matching_blocks() for k in range(b.size)]
    med = float(np.median(np.abs(off))) if off else 9.9
    check("caption_sync", med <= 0.12, f"median |offset| {med:.3f}s over {len(off)} words", "<= 0.12 s")

# ---------------------------------------------------------------- contact sheet for visual review
sheet = reel / "contact-sheet.jpg"
rows = int(np.ceil(dur * 2 / 8))
run(["ffmpeg", "-v", "error", "-y", "-i", str(video), "-vf", f"fps=2,scale=180:320,tile=8x{max(rows, 1)}", "-frames:v", "1", "-q:v", "3", str(sheet)])

ok = all(c["pass"] for c in checks)
report = {"status": "pass" if ok else "fail", "video": str(video), "duration_s": round(dur, 3), "integrated_lufs": lufs,
          "true_peak_dbtp": tp, "checks": checks, "contact_sheet": str(sheet), "qa_seconds": round(time.time() - t_start, 1),
          "note": "Automated checks only. Look at contact-sheet.jpg and watch the video with sound before posting: "
                  "ASR checks the words, not how they sound."}
common.save_json(reel / "qa.json", report)
for c in checks:
    print(f"{'PASS' if c['pass'] else 'FAIL'}  {c['check']:<28} {c['value']}   (want {c['want']})")
print(f"\nQA {'PASSED' if ok else 'FAILED'}: {sum(c['pass'] for c in checks)}/{len(checks)} checks. "
      f"Report: {reel / 'qa.json'}  Look at: {sheet}")
sys.exit(0 if ok else 1)
