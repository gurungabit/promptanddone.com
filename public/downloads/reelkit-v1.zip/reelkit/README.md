# reelkit

A small starter kit for making short vertical videos (1080x1920, 25-35 s) with **Claude Code**: an AI voice reads your script, Whisper checks every word, a three.js 3D scene acts it out with word-synced captions, and the result is rendered, mixed and checked automatically. Everything except Claude Code runs free on your own computer.

You give Claude Code a topic. It follows the skill in `.claude/skills/make-reel/` (research -> real test -> fact check -> script -> voice -> ASR gate -> 3D scene -> render -> mix -> QA -> package) and hands you a finished MP4. **You watch it and decide whether to post it.** The kit never posts anything.

The sample in `example/` renders an 11.4 s video of an original voxel robot on a floating island, from a three-line script, in about a minute.

## 10-minute setup (macOS)

You need: a Mac (Apple silicon tested), [Claude Code](https://code.claude.com/docs/en/setup) on a paid Claude plan, Homebrew, and about 2.5 GB of free disk.

```sh
brew install ffmpeg node uv                        # ffmpeg 6+, Node 18+, uv (Python manager)
curl -fsSL https://claude.ai/install.sh | bash     # Claude Code (then run `claude` once to log in)

unzip reelkit-v1.zip && cd reelkit
make setup        # Python 3.12 env + Node packages + headless Chromium (about 1.7 GB, a few minutes)
make doctor       # every line should say ok
make all          # renders the sample: example/final.mp4 (first run also downloads the voice and Whisper models, ~0.8 GB)
```

Open `example/final.mp4`, `example/contact-sheet.jpg` and `example/qa.json`. Then fill in `CLAUDE.md` (your channel) and start Claude Code in this folder.

**Linux (untested in v1):** `sudo apt install ffmpeg nodejs npm` (Node 18+), install [uv](https://docs.astral.sh/uv/), and before `make setup` install the CPU build of torch so you don't download CUDA: `uv venv --python 3.12 .venv && VIRTUAL_ENV=$PWD/.venv uv pip install torch==2.15.0 --index-url https://download.pytorch.org/whl/cpu`. Use `npx playwright install --with-deps chromium` for the browser's system libraries. Without a GPU, Chromium renders WebGL in software (slower, same result).

**Windows (untested in v1):** the easy path is WSL 2 (Ubuntu) and the Linux steps. Native Windows works in principle (ffmpeg via `winget install Gyan.FFmpeg`, Node, uv), but `make` and `finish.sh` need Git Bash; or run each Makefile target's command by hand.

## Your first prompt

In the reelkit folder, run `claude` and paste:

```text
Make one reel about <TOPIC>.
Follow CLAUDE.md and the make-reel skill end to end: research and prove demand, test it for real,
build the claim table, write the script, voice, ASR gate, build the scene, render, mix, run QA and
fix what fails, then package it. Don't stop to ask me unless you are blocked.
Look at the contact sheets yourself before you call it done.
Do not post anything. When you finish, give me the MP4 path, its duration, the QA result,
and anything you could not verify.
```

More prompts (research only, revise, a batch "make N reels while I sleep" orchestrator) are in `PROMPTS.md`.

## Send the link to everyone who comments (optional)

Most reels end with "Comment KEYWORD and I'll send you the link." Sending that link by hand to every commenter doesn't scale, and a promised link that never arrives costs you trust. **[Replybeam](https://replybeam.app)** does it for you on Instagram: when someone comments your keyword it posts a short public reply and DMs them your link as a button, and it tracks the clicks.

- **Try it free:** the free-forever plan has no credit card: 2 running automations and 1,000 DMs a month. Pro ($9/month) removes the limits.
- **The agent asks you.** When a reel's CTA is a comment keyword, Claude Code asks once whether you want it, then writes the exact settings to paste (make-reel skill, step 12; prompt 6 in `PROMPTS.md`).
- **On Pro, Claude Code can set it up itself** through Replybeam's connector: `claude mcp add --transport http replybeam https://replybeam.app/mcp`. It still asks before turning anything on.

Disclosure: Replybeam is made by the team behind Prompt & Done.

## How the pipeline works

| Stage | Command | What happens | Gate (must pass) |
|---|---|---|---|
| Research | (Claude Code, web search) | sweep this week's attention, prove demand with real numbers, rank 5-8 candidates, pick one | ranked table + demand links |
| Test | (Claude Code) | run the tool for real; save the input and output | a real output on disk |
| Claims | (Claude Code) | claim table from primary sources | every scripted fact has a source |
| Script | edit `script.json` | one spoken paragraph split into lines; hook in 1-2 s; one CTA | 75-95 words, claims covered |
| Voice | `make voice` | Kokoro-82M: one take per speed x seed for every line | takes on disk |
| ASR gate | `make gate` | Whisper transcribes every take; only exact word matches pass; best pace wins; assembles `voiceover.wav` + `timeline.json` (word times) | `GATE PASS` |
| 3D scene | `make stills`, `make preview` | three.js scene, deterministic `draw(t)`, one camera path, word-synced captions | contact sheet with no faults |
| Render | `make render` | headless Chromium steps through every frame (30 fps) -> `picture.mp4` | no page errors |
| Mix | `make sound`, `make finish` | original music bed + SFX, ducked under the voice, -14 LUFS, true peak <= -1.5 dBTP, encoded 1080x1920 H.264 High + AAC 48 kHz, fast-start | - |
| QA | `make qa` | 16 automated checks on the encoded file + `contact-sheet.jpg` | `QA PASSED` + your own look |
| Package | `make cover`, `post.md` | cover image, title, caption, sources | a human approves |

`make all REEL=reels/<slug>` runs voice -> gate -> sound -> render -> finish -> qa. `make new SLUG=<slug>` starts a reel in `reels/<slug>/` with its own copy of the scene to edit.

### Files

```
CLAUDE.md                     your channel's rules (fill in)
PROMPTS.md                    copy-paste prompts
.claude/skills/make-reel/     the end-to-end skill + references/hooks.md, references/qa.md
engine/voice.py               TTS takes (Kokoro default, Chatterbox optional)
engine/asr_gate.py            Whisper exact-match gate, voiceover + word timeline
engine/sound.py               synthesized music bed + SFX (no samples, no licences needed)
engine/scene/                 index.html + scene.js: the three.js starter scene
engine/render.mjs             Playwright frame-by-frame renderer (+ stills, preview server)
engine/finish.sh              mix, loudness, encode
engine/qa.py                  automated QA -> qa.json
example/script.json           the sample reel
reels/<slug>/                 your reels: script.json, scene/, assets/, research.md, post.md and generated files
```

### script.json

```json
{
  "kicker": "sample reel",
  "lines": [
    {"id": "hook", "text": "One script in. A finished vertical video out."},
    {"id": "price", "text": "It costs $5.", "say": "It costs five-dollars."}
  ],
  "cues": [{"at": "hook/out", "do": "jump"}, {"at": "price/costs", "do": "check"}],
  "voice": {"engine": "kokoro", "kokoro_voice": "af_heart", "speeds": [1.0, 1.1], "seeds": [1, 2]},
  "asr": {"model": "small.en", "prompt": "Names Whisper should know.", "target_wps": 2.9},
  "timing": {"lead_in": 0.0, "gap": 0.25, "tail": 0.8, "tempo": 1.0},
  "screen": {"image": "assets/output.png", "label": "REAL OUTPUT"}
}
```

`text` is what the captions show, `say` what the voice reads (same number of words; join a spoken form with hyphens). Cue actions: `wave jump spin nod point check push`. Anchors: `2.5`, `"line"`, `"line@end"`, `"line/word"`, `"line/word#2"`, plus an optional `" +0.2"`.

## Tested

4 Nov 2026 on macOS 26.5.1, Apple M5 Max (64 GB), Python 3.12.15 (uv 0.13.0), Node 24.21.0, ffmpeg 9.0.2, Playwright 1.64.1 (Chromium 156, WebGL on Metal), three.js 0.180.0, kokoro 0.9.4, torch 2.15.0, faster-whisper 1.2.1 (CTranslate2 4.8.5, PyAV 18.1.0). Sample reel, models already downloaded:

| Stage | Time |
|---|---|
| voice (12 takes) | 7 s |
| gate (12 takes + assembly) | 22 s |
| sound | < 1 s |
| render (342 frames, 1080x1920) | 6 s (about 58 fps) |
| finish | 5 s |
| qa | 3 s |

QA on the sample: 16/16 checks passed (-14.1 LUFS, -2.0 dBTP, no flashes, 0 hard cuts, Whisper heard the script exactly, median caption offset 5 ms). A slower Mac or a machine without a GPU will be slower, mostly in render.

## The stack

| Part | What it does | License |
|---|---|---|
| [Claude Code](https://code.claude.com/docs/en/setup) | runs the whole process | needs a Pro, Max, Ultra, Team, Enterprise or Console (API) account; the free plan does not include it |
| [Kokoro-82M](https://huggingface.co/hexgrad/Kokoro-82M) (`kokoro`, `misaki`) | text to speech, on CPU | Apache-2.0 |
| espeak-ng (bundled by `espeakng-loader`), `phonemizer-fork` | pronunciation fallback for Kokoro | GPL-3.0 |
| spaCy + `en_core_web_sm` | English text analysis for Kokoro | MIT |
| PyTorch | runs Kokoro | BSD-3-Clause (plus bundled third-party licenses) |
| [faster-whisper](https://github.com/SYSTRAN/faster-whisper) + Whisper `small.en` | speech to text for the gate and QA | MIT |
| num2words | numbers to words for the word match | LGPL |
| [three.js](https://threejs.org) | 3D scene in the browser | MIT |
| [Playwright](https://playwright.dev) + Chromium | headless frame-by-frame rendering | Apache-2.0 (Chromium: BSD-style) |
| [FFmpeg](https://ffmpeg.org) | mixing, loudness, encoding | LGPL/GPL (Homebrew builds with x264 are GPL) |
| Chatterbox (optional) | voice cloning | MIT |
| [Replybeam](https://replybeam.app) (optional) | sends the link to everyone who comments your keyword on Instagram | free plan; Pro $9/month |
| reelkit itself | the glue, scene, skill and docs | MIT |

The music and sound effects are synthesized by `engine/sound.py` from plain math, so there is nothing to license. If you use your own track, you need the rights to it.

## FAQ

**What does it cost?** The kit and every tool in it are free. Claude Code needs a paid Claude plan (on 4 Nov 2026, claude.com/pricing listed Pro at $20 a month billed monthly, with Claude Code included) or API credits. A full reel uses a fair share of a session's usage on the smaller plans, because Claude researches, writes code and looks at images.

**What hardware?** Any recent Mac, Linux or Windows machine with 8 GB of RAM should run Kokoro and Whisper `small.en` on the CPU. A GPU makes the 3D render much faster (Apple silicon uses Metal automatically). Disk: about 1.1 GB for the Python env, 0.6 GB for Chromium, 0.8 GB of models.

**Can I clone my own voice?** Yes, with the optional Chatterbox engine (MIT): record 10-15 s of yourself, clean and without music, set `"voice": {"engine": "chatterbox", "reference": "assets/my-voice.wav", "seeds": [1, 2, 3, 4]}` and run it in its own env:

```sh
uv venv --python 3.11 .venv-clone && VIRTUAL_ENV=$PWD/.venv-clone uv pip install -r requirements-chatterbox.txt
make voice PY=.venv-clone/bin/python REEL=reels/<slug>     # then make gate etc. as usual
```

Honest notes: we did not run Chatterbox in the v1 test (its env resolves; the model is a ~3 GB download); Resemble AI archived the project in Aug 2026, so it gets no more fixes; every output carries Resemble AI's inaudible Perth watermark. **Only clone your own voice, or a voice whose owner gave you written permission.**

If you have a big-memory Mac, **Fish Audio Drama 3** (open weights, [fishaudio/drama-3](https://huggingface.co/fishaudio/drama-3)) is the high-end local option: in our setup it peaks at about 47 GB of RAM, so think 64 GB machines. Its Fish Audio Community License allows commercial use while your annual revenue is under USD 500,000, forbids offering it as a hosted voice service, forbids imitating a real person's voice without consent, and requires you to show "Built with Fish Audio" on a related page. reelkit does not include a Drama 3 adapter; ask Claude Code to add one to `engine/voice.py` that writes takes the same way.

**Is local TTS as good as the paid voices?** Not always. Kokoro is clear and fast, but it can sound flat; listen to the takes the gate picks. Swapping in another engine only means writing WAV takes to `reels/<slug>/takes/` and listing them in `takes.json`; the gate and everything after stay the same.

**Can it post for me?** No, on purpose. A human should watch every video with sound before it goes out: ASR proves the words, not how they sound, and only you can judge whether a claim, a joke or a visual is right for your audience. Check each platform's rules for labelling AI-generated or synthetic content, and never imply a synthetic voice is a real person.

**The gate keeps failing.** Read the diff it prints. Usually Whisper writes a word differently ("on cue" -> "on queue", "raced" -> "raised"): rephrase, add the name to `asr.prompt`, or add a `token_map` entry for a pure spelling variant. More takes: `.venv/bin/python engine/voice.py reels/<slug> --lines ID --seeds 3,4,5,6`.

**The render is black or very slow.** Run `make stills` and read the console lines. On Linux without a GPU, WebGL falls back to SwiftShader (software): slow but correct. You can pass extra Chromium flags with `REELKIT_CHROME_ARGS="--use-gl=angle --use-angle=swiftshader"`.

**Port 8860 is busy.** `make render PORT=8861` (also `stills`, `preview`).

## Troubleshooting quick list

- `make doctor` says MISSING: run `make setup`, or install the tool it names.
- Harmless warnings during `make voice` (torch, LSTM dropout, weight norm) can be ignored.
- After changing words, run `make gate` again before `make render`: the picture follows `timeline.json`.
- Delete a reel's generated files with `make clean REEL=reels/<slug>` (keeps script.json, scene/, assets/).

MIT licensed (see LICENSE).
