# Channel instructions (fill this in)

Claude Code reads this file at the start of every session in this folder. Replace every `<...>`. Keep it short: rules here apply to every video. The step-by-step production process lives in `.claude/skills/make-reel/SKILL.md`.

## The channel

| | |
|---|---|
| Name | `<Channel name>` |
| Promise (one line) | `<e.g. "One AI tool a day that saves you an hour. Shown, not told.">` |
| Audience | `<who, what they already know, what they want: e.g. "people who use ChatGPT or Claude at work and want to do more with it">` |
| Niche to research | `<topics in scope, e.g. "AI tools, agents, coding assistants, open-source AI you can run">` |
| Out of scope | `<e.g. "crypto, finance tips, politics, celebrity news">` |
| Handles | `<TikTok @...> / <Instagram @...> / <YouTube @...>` |
| Length | 25-35 s by default (75-95 spoken words) |

## Voice and tone

- `<e.g. "Calm, confident, a little dry. Talks like a friend showing you something on their laptop.">`
- Write for speech: short clauses, contractions, one idea per sentence, concrete examples.
- Never: "Hey guys", "Welcome back", "In today's video", "game-changing", "revolutionary", "insane".
- TTS voice: `<Kokoro voice id, e.g. af_heart or am_michael>` (set `voice.kokoro_voice` in each script.json).

## Hook rules

- The first 1-2 seconds show the result or the surprising capability. Never open on a logo, a greeting or the tool's name.
- Speech starts at 0.0 s. Frame 0 is the most striking image in the video.
- Proof on screen by about 3 s.

## Call to action

- One CTA, after the payoff, while the scene is still moving.
- Default: `<"Comment KEYWORD and I'll send you the link." or "Follow for one AI tool a day.">`
- A keyword is short, distinctive and not a common word. Only promise what exists and works.
- Comment-to-DM: `<yes/no>`. If yes, every "Comment KEYWORD" reel gets a `dm-automation.md` for Replybeam (make-reel skill, step 12). Replybeam sends the link to everyone who comments on Instagram; it has a free plan: https://replybeam.app

## Accuracy rules

- Fresh research before every script. Never script from memory.
- Every claim (names, prices, plans, licences, dates, capabilities, numbers) has a primary source or our own test in the reel's claim table.
- Never repeat a creator's claim without checking it. Never invent numbers or engagement.
- Scope claims precisely instead of adding spoken disclaimers. Put prerequisites (paid plan, hardware) in the post caption.
- Label illustrative scenes. Show the real input and the real output whenever possible.
- Never clone or imitate a real person's voice without their written consent. Never use a trademarked mascot or logo as a character.

## Quality bar

- 1080x1920, 30 fps, H.264, AAC, -14 LUFS, true peak <= -1.5 dBTP.
- `make qa` passes, and you looked at the contact sheet and the key frames yourself.
- Captions: max 4 words, word-synced, nothing overlapping the hero.
- One continuous 3D world per video, at most two hard cuts, something new every 2-4 s.

## Log of past videos (avoid repeats)

| Date | Slug | Topic | Notes |
|---|---|---|---|
| `<yyyy-mm-dd>` | `<slug>` | `<topic>` | `<what worked, what didn't>` |

## Permissions

- **Never post, schedule, upload or send anything without my explicit OK for that specific video.** Deliver the finished file and the package; I watch it and decide.
- Do not spend money (paid APIs, subscriptions) without asking. `<adjust if you allow a budget, e.g. "up to $2 of API calls per video">`
- Work inside this folder. Don't delete anything outside `reels/<slug>/`.
