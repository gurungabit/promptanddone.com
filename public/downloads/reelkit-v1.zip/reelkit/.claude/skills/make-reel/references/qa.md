# QA checklist

Run QA on the encoded `final.mp4`, never on the browser preview. `make qa REEL=reels/<slug>` runs every automated check below and writes `qa.json` and `contact-sheet.jpg`. Exit code 1 = something failed.

## Automated checks (engine/qa.py)

| Check | Pass when | If it fails |
|---|---|---|
| resolution | 1080x1920 | the scene canvas or render size was changed: keep W, H = 1080, 1920 |
| video_codec | h264, High profile, yuv420p | re-run `make finish` (it sets `-profile:v high -pix_fmt yuv420p`) |
| frame_rate | exactly 30/1 | re-run `make render` then `make finish` |
| audio | AAC, 48 kHz, 2 channels | re-run `make finish` |
| faststart | `moov` atom before `mdat` | `make finish` uses `-movflags +faststart`; don't re-mux with other tools |
| duration_range | between `qa.min_seconds` and `qa.max_seconds` (default 5-90) | cut words, or set `qa` limits in script.json on purpose |
| duration_matches_timeline | final duration within 0.09 s of `timeline.json` | the picture is stale: `make render` after every `make gate` |
| loudness | -14 LUFS +/- 1 (integrated) | re-run `make finish`; check `voiceover.wav` isn't near-silent |
| true_peak | <= -1.5 dBTP | lower the limiter target in finish.sh (`-2.3` -> `-2.8`) |
| frame_count | frames = duration x 30 (+/- 1) | re-render |
| first_frame_not_blank | frame 0 mean luma >= 18 and std >= 8 | frame 0 must be a real image: no fade from black, everything visible at t = 0 |
| no_one_frame_flashes | no frame jumps away from both neighbours (whole frame > 3 luma, or any 1/16 region > 12) | find the frame; usual causes: bloom on a glossy or white surface, an object popping in for one frame, a texture redrawn late |
| hard_cuts | scene-change score > 0.3 at most `qa.max_cuts` times (default 2) | smooth the camera; out-of-order camera keys cause one-frame jumps |
| speech_starts_early | first word at <= 0.30 s | `timing.lead_in` = 0 |
| final_audio_matches_script | Whisper on the final mix = the script's `say` words, exactly | music or SFX masking a word: lower `--music-db`/`--sfx-db` in `make sound`, or move a whoosh; re-run the gate if a take changed |
| caption_sync | median caption-vs-audio offset <= 0.12 s | the timeline is stale or edited by hand: re-run `make gate` |

## The same checks by hand (any reel, any tool)

```sh
V=reels/<slug>/final.mp4
ffprobe -v error -show_entries format=duration:stream=codec_name,profile,width,height,r_frame_rate,pix_fmt,sample_rate,channels -of json "$V"
ffmpeg -hide_banner -nostats -i "$V" -af ebur128=peak=true -f null - 2>&1 | grep -E '^ +(I|Peak):'   # I: about -14 LUFS, Peak (true peak): <= -1.5
ffmpeg -hide_banner -i "$V" -vf "select='gt(scene,0.3)',showinfo" -f null - 2>&1 | grep -c pts_time   # hard cuts: <= 2
ffmpeg -v error -i "$V" -vf "fps=2,scale=180:320,tile=8x4" -frames:v 1 /tmp/sheet.jpg      # contact sheet: LOOK at it
ffmpeg -v error -i "$V" -vf "scale=72:128,format=gray" -f rawvideo - | python3 -c "
import sys, numpy as n
d = n.frombuffer(sys.stdin.buffer.read(), n.uint8).reshape(-1, 128, 72).mean((1, 2))
a, b, c = d[:-2], d[1:-1], d[2:]
print([round(i / 30, 2) for i in n.flatnonzero((abs(b - a) > 3) & (abs(b - c) > 3) & (n.sign(b - a) == n.sign(b - c)) & (abs(a - c) < 1.5)) + 1])"   # one-frame flashes: must print []
ffmpeg -v error -i "$V" -vf "select=eq(n\,0),scale=72:128,format=gray" -f rawvideo - | python3 -c "import sys,numpy as n; d=n.frombuffer(sys.stdin.buffer.read(),n.uint8); print('frame 0 mean', d.mean(), 'std', d.std())"   # not black
```

## What you check with your eyes (no script can)

Open `contact-sheet.jpg`, then full-size frames (`ffmpeg -ss 3.2 -i final.mp4 -frames:v 1 /tmp/f.png`) at 0.0 s, 0.5 s, 1.5 s, 3 s, every caption change you doubt, the payoff, the CTA and the last frame.

- Frame 0 is the most striking image in the video. Speech starts immediately.
- A viewer understands what the thing does after one watch; the hook's promise is paid off; the best fact lands within ~8 s.
- The real input and the real output are both visible; the output is big (fills most of the frame at least once).
- Every spoken and on-screen claim is in the claim table. Illustrative scenes are labelled.
- The hero is lit, prominent, never inside geometry, never hidden behind text or captions (captions live at y 1380-1500).
- Something meaningful changes every 2-4 s; no still image with a slow pan.
- Text is at least 28 px at 1080 wide, nothing overlaps, no one-word caption orphans, no missing or wrong caption words.
- One CTA, after the payoff, inside the live scene; the last line echoes the hook.
- Nothing important in the top ~220 px or bottom ~400 px (app UI covers them).

## Honest limits

ASR proves the words, not how they sound. Before posting, a human watches the whole video with sound on a phone. Record anything you could not check (you cannot listen) in your report.
