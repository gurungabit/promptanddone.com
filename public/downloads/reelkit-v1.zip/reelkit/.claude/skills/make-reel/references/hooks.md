# Hooks and script rules

## The shape of a 30-second reel

HOOK (0-2 s: the finished result or the impossible-sounding capability) -> WHAT IT IS (one plain sentence) -> THE INPUT (the prompt, command or click appears) -> THE OUTPUT (the strongest visual moment) -> ESCALATION (a second, bigger capability or the real-world use) -> PAYOFF (what it saves you) -> CTA (one action) -> a last line that echoes the hook so the loop feels seamless.

## Write for speech

- Write the whole voiceover as one connected paragraph first, then split it into lines.
- Short clauses, contractions, one idea per sentence, a new reveal every few seconds.
- Every clause should name something the scene can do on those words ("you type one sentence" -> the screen types it; "and it builds" -> the thing assembles).
- Lead with the outcome. The tool's name comes after the viewer has a reason to care.
- Explain any unfamiliar term in plain words the first time. Give every "it" and "this" a clear referent.
- No hype words ("revolutionary", "game-changing", "insane"), no "In today's fast-paced world", no staged questions ("Wait, what?"). Show why it is impressive instead of saying so.
- No spoken caveats. Scope the claim precisely ("on a paid plan" belongs in the caption; "it wrote the first draft" beats "it does everything").
- 75-95 words for 25-35 s. Read it aloud once; cut whatever you stumble on.

## Hooks: draft five, keep the strongest

Never open with a greeting, the channel name, a logo or "Today we're going to". Speech starts at 0.0 s and frame 0 already shows something worth stopping for.

Shapes that work (adapt them; never copy another creator's line):

- **Result first:** "One sentence. That's all it took to make this." (the finished thing is on screen)
- **You can now:** "You can now [desirable outcome] by [trivial input]."
- **Free replacement:** "Stop paying for [familiar paid tool]. This does it free." (only when you verified it)
- **Manual habit:** "Still [tedious task] by hand?"
- **Name + verb:** "[Company]'s AI just [did a concrete thing]."
- **Impossible pair:** "I typed a sentence. It printed a bracket."
- **Negation (explainers):** "Your AI has no memory. So how does it remember you?" (every negation verified)

Pair the line with a big visual action in frame 0, show proof within ~3 s, and pay off the promise. A dramatic hook must resolve into the real, demonstrated result.

## Call to action

One action, after the payoff, while the scene is still alive. Default: "Comment KEYWORD and I'll send you the link." The keyword is short, distinctive and not a common word (common words trigger automations by accident). Only promise what actually exists and works. With nothing to send, use a follow line instead.

## Make the voice and the ASR gate agree

- Numbers: write them as words in `say` ("five dollars"), keep the symbol in `text` ("$5"), same word count (`"$5"` <-> `"five-dollars"`).
- Names: write them the way they sound in `say` if the voice mangles them, and add the real spelling to `asr.prompt`.
- Avoid near-homophones in key spots: "on cue" (Whisper writes "on queue"), "raced" vs "raised". The gate compares spelling, so a word that can be written two ways fails even when it sounds right.
- If every take of a line fails on the same word, rewrite the line. Do not fight the model.

## Captions

Max 4 words per caption, the word being spoken is highlighted, breaks at punctuation and line changes, no one-word orphans. Never put a big headline on screen that repeats the caption.

## Caption text for the post (platform description)

300-450 characters: the CTA line first, a one-line hook, one or two sentences on what it is and why it's useful, a disclosure if needed, 4-6 hashtags. Sources and steps go on the resource page, not in the caption.
