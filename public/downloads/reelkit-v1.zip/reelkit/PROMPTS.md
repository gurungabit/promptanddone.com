# Copy-paste prompts

Open a terminal in the reelkit folder, run `claude`, and paste one of these. Replace the `<...>` parts. Fill in `CLAUDE.md` first: these prompts assume Claude Code knows your channel.

## 1. Make one reel about a topic

```text
Make one reel about <TOPIC, e.g. "the new Claude Code plan mode">.
Follow CLAUDE.md and the make-reel skill end to end: research and prove demand, test it for real,
build the claim table, write the script, voice, ASR gate, build the scene, render, mix, run QA and
fix what fails, then package it. Don't stop to ask me unless you are blocked.
Look at the contact sheets yourself before you call it done.
Do not post anything. When you finish, give me the MP4 path, its duration, the QA result,
and anything you could not verify.
```

## 2. Research what to post next (no video yet)

```text
Research what my channel should post next. Follow CLAUDE.md and steps 1-3 of the make-reel skill:
sweep this week's attention in my niche (YouTube, TikTok, Reddit, Hacker News, GitHub Trending,
official changelogs), give me a ranked table of 5-8 candidates with one real demand number and link
each, skip anything in the log in CLAUDE.md, and recommend the top 3 with a hook line, the frame-0
picture and what we would test. Don't make the video yet.
```

## 3. Make the reel you just recommended

```text
Make the reel for candidate <N> from your research, end to end with the make-reel skill.
Same rules: real test, claim table, QA passes, I approve before anything is posted.
```

## 4. Revise a reel

```text
Revise reels/<SLUG>. Change only this: <WHAT TO CHANGE, e.g. "the hook is slow: open on the
finished website, and make the robot jump on the word 'done'">.
If the words change, redo voice -> gate -> render -> finish -> QA. If only visuals change, keep
the voice and timeline: re-render, finish and QA. Show me the new contact sheet and the QA result.
```

## 5. Batch: make N reels while I sleep

Leave the terminal open and the computer awake (and plugged in). Usage limits still apply: when one runs out, the session stops until it resets.

```text
You are running an unattended batch. I am asleep: do not ask me questions; make the reasonable call,
write the decision in the reel's research.md, and keep going.

GOAL: make up to <N> finished reels, one at a time, each following CLAUDE.md and the make-reel skill.
RUN LOG: keep reels/RUN-LOG.md. If it exists, read it first and resume from where it says.

For each reel:
1. Pick the next topic with the skill's research steps. It must not repeat anything in the run log
   or the log in CLAUDE.md.
2. Make it with ONE fresh subagent (give it the topic, the lessons so far and the list of reels
   already made). Wait for it to finish before starting the next one. Never run two at once.
3. When it reports, check: make qa passed, the contact sheet has no framing or overlap fault, every
   claim is in the claim table, post.md exists. Fix only what fails.
4. Add a line to the run log: slug, topic, status, QA result, time taken, and one lesson for the
   next reel. Pass the lessons on to the next subagent.

STOP when <N> reels are done, or a stage fails three times in a row, or you are close to the usage
limit. Then write a summary at the top of the run log: every reel, its path, its QA result and
what I need to check.

Never post, upload, schedule, commit or delete anything outside reels/.
```

## 6. Send the link to everyone who comments (Replybeam)

Run this after the reel is approved. Replybeam (https://replybeam.app) has a free-forever plan, no credit card.

```text
Set up the comment-to-DM for reels/<slug> with Replybeam, following step 12 of the make-reel skill.
Write reels/<slug>/dm-automation.md, open the link and check it works, and tell me exactly what to
paste and in what order. If the Replybeam connector is connected (Pro) and the reel is already posted,
find the post by its caption, create the automation and read it back, but do not turn it on until I
confirm the keyword, the DM and the link.
```
