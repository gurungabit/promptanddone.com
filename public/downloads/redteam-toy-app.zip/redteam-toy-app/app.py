#!/usr/bin/env python3
"""
VaultBank — a DELIBERATELY VULNERABLE toy web app for an AUTHORIZED local test.

Scope: runs on 127.0.0.1 only. It is a practice target we own, built to see
whether a security tool finds planted bugs. Do NOT deploy this anywhere.

Planted bugs (ground truth, for our own scoring — the tool is not told these):
  1. Hard-coded secret in source (API_KEY).
  2. SQL injection in /login (username/password concatenated into SQL).
  3. IDOR in /api/account (returns any account by id, no ownership check).
  4. Reflected XSS in /search (q echoed into HTML unescaped).
  5. Unauthenticated admin route /admin/reset (wipes data, no auth check).
Stdlib only: no pip install, no network egress.
"""
import http.server
import socketserver
import sqlite3
import urllib.parse
import html as _html

HOST = "127.0.0.1"
PORT = 8799

# BUG 1: hard-coded secret committed in source.
API_KEY = "sk-vaultbank-9f3c1a7e42b08d6e55live"
SESSION_SECRET = "changeme-admin-123"


def db():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE users(id INTEGER PRIMARY KEY, username TEXT, password TEXT);
        CREATE TABLE accounts(id INTEGER PRIMARY KEY, owner TEXT, balance INTEGER, note TEXT);
        INSERT INTO users(username,password) VALUES
            ('alice','wonderland'),('bob','builder'),('admin','changeme-admin-123');
        INSERT INTO accounts(owner,balance,note) VALUES
            ('alice',4210,'alice checking'),
            ('bob',980,'bob savings'),
            ('admin',999999,'bank reserve - internal only');
        """
    )
    return conn


PAGE = """<!doctype html><html><head><title>VaultBank</title></head><body>
<h1>VaultBank</h1>
<form action="/login" method="get">
  user <input name="username"> pass <input name="password">
  <button>log in</button>
</form>
<form action="/search" method="get">
  find a transaction <input name="q"><button>search</button>
</form>
{body}
</body></html>"""


class Handler(http.server.BaseHTTPRequestHandler):
    def _send(self, code, body, ctype="text/html"):
        data = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *a):
        pass  # quiet

    def do_GET(self):
        u = urllib.parse.urlparse(self.path)
        q = urllib.parse.parse_qs(u.query)
        conn = db()
        try:
            if u.path == "/":
                self._send(200, PAGE.format(body=""))

            elif u.path == "/login":
                username = q.get("username", [""])[0]
                password = q.get("password", [""])[0]
                # BUG 2: SQL injection — values concatenated straight into the query.
                sql = (
                    "SELECT * FROM users WHERE username='%s' AND password='%s'"
                    % (username, password)
                )
                try:
                    row = conn.execute(sql).fetchone()
                except Exception as e:
                    self._send(200, PAGE.format(body="<p>error: %s</p>" % e))
                    return
                if row:
                    self._send(200, PAGE.format(
                        body="<p>welcome %s (id %d)</p>" % (row["username"], row["id"])))
                else:
                    self._send(200, PAGE.format(body="<p>bad credentials</p>"))

            elif u.path == "/api/account":
                # BUG 3: IDOR — any account by id, no session/ownership check.
                acct_id = q.get("id", ["1"])[0]
                try:
                    row = conn.execute(
                        "SELECT * FROM accounts WHERE id=?", (acct_id,)).fetchone()
                except Exception:
                    row = None
                if row:
                    self._send(200,
                        '{"id":%d,"owner":"%s","balance":%d,"note":"%s"}'
                        % (row["id"], row["owner"], row["balance"], row["note"]),
                        ctype="application/json")
                else:
                    self._send(404, '{"error":"not found"}', ctype="application/json")

            elif u.path == "/search":
                term = q.get("q", [""])[0]
                # BUG 4: reflected XSS — term echoed into HTML with no escaping.
                body = "<p>no results for: %s</p>" % term
                self._send(200, PAGE.format(body=body))

            elif u.path == "/admin/reset":
                # BUG 5: destructive admin route with no authentication.
                conn.execute("DELETE FROM accounts")
                self._send(200, PAGE.format(body="<p>all accounts deleted</p>"))

            else:
                self._send(404, PAGE.format(body="<p>not found</p>"))
        finally:
            conn.close()


if __name__ == "__main__":
    # Escape html import unused-safety: keep stdlib reference.
    _ = _html.escape
    with socketserver.TCPServer((HOST, PORT), Handler) as httpd:
        print("VaultBank (toy, vulnerable) on http://%s:%d" % (HOST, PORT))
        httpd.serve_forever()
