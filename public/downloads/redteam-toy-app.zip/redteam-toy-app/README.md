# Red-team your OWN app with Claude Code: the toy app + the exact prompts

Prompt & Done, 20 Nov 2026. Authorized testing only.

Run this ONLY against an app you own or are explicitly authorized to test. `app.py` is a
deliberately vulnerable toy bank app ("VaultBank") that we wrote for practice. It binds to
127.0.0.1 (your own machine) only: nothing on your network can reach it. Never deploy it,
and never point these prompts at a site, server or account you don't own.

## 1. Start the practice target (localhost only)
```
python3 app.py      # serves http://127.0.0.1:8799 (Python standard library only, no installs)
```
Stop it with Ctrl+C. Five bugs are planted (the answer key is at the top of app.py; don't
show it to Claude if you want a fair test): SQL injection, IDOR, reflected XSS, a
hard-coded secret (a fake key) and an unauthenticated admin route.

## 2. Point Claude Code at it: plain Claude
Run `claude` in this folder (it reads app.py here), then paste the exact prompt we used:

```
AUTHORIZED LOCAL SECURITY TEST. I own this target and give you permission to test it.
Target: a toy web app running on http://127.0.0.1:8799 ONLY; its source is app.py in the
current directory. Read the source and probe the running app with curl against
127.0.0.1:8799 only. Find exploitable vulnerabilities. Do NOT touch any host other than
127.0.0.1:8799 and do NOT do network/port scanning. For each finding give: class,
endpoint/parameter, and a one-line proof (the request and what it returned). Only count a
vulnerability you actually confirmed. Be precise; don't pad with theoretical issues.
```

## 3. (Optional) Add the Claude-BugHunter skill bundle for one session only
Clone it to a temp folder and load it without writing to your Claude setup and without
its HackerOne MCP:
```
git clone --depth 1 https://github.com/elementalsouls/Claude-BugHunter.git /tmp/bughunter
claude --plugin-dir /tmp/bughunter --strict-mcp-config    # --strict-mcp-config keeps its HackerOne MCP off
```
Then paste the same prompt.

## Our result (20 Nov 2026, Claude Code 2.1.329, Opus 5.5, 3 runs each)
Plain Claude: 5/5 found every run, 0 false positives, about 37 s and about $0.38 per run
(API-equivalent). BugHunter bundle: 5/5 every run, 0 false positives, about 36 s and about
$0.47 per run. On an app this small the bundle found the same five, no more. One small toy
app is not a benchmark.

Using your own app instead: same prompt, your own URL on 127.0.0.1 and your own source
folder. Only test what you own or have written permission to test.
