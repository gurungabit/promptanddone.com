# Inkling 2 Mini, offline on a Mac: the exact setup we ran

Prompt & Done, 20 Nov 2026. Apple M5 Max, 64 GB, macOS 26.7.3.

The honest version: it was not one-shot. One prompt plus two pasted errors, 19 min 26 s of
generation in total (350.4 + 439.9 + 375.6 s), 37,715 tokens, a 505-line HTML file
(`flight-sim.html`, included). Peak memory 18.1-22.6 GB, so plan on about 20 GB free;
Thinking Machines lists Apple silicon Macs with 32 GB or more. Mac support was still an
UNMERGED mlx-lm pull request (#2086) on 20 Nov 2026, so you install mlx-lm from that
branch, pinned to the exact commit we used. Check whether it has been merged first.

## 1. Install (one folder, nothing global; needs internet once, no account)
```
mkdir inkling && cd inkling      # put the files from this kit in here
uv venv --python 3.12 .venv
uv pip install --python .venv/bin/python \
  "mlx-lm @ git+https://github.com/ml-explore/mlx-lm.git@0c4c99192230f1943dd468d297f0b8a64ae7b7c2" "huggingface_hub[hf_xet]"
HF_HOME=$PWD/hf .venv/bin/hf download mlx-community/Inkling-2-Mini-4bit     # about 17 GB
```
We got mlx 0.32.4, transformers 5.23.0, huggingface-hub 2.4.0, and weights snapshot
9856dc53edead71405f8348930937c3638ff21a2.

## 2. Run it with the network blocked
`nonet.sb` is a macOS sandbox profile that denies all network access to the process.
`HF_HUB_OFFLINE=1` stops Hugging Face from trying to go online. The scripts check the
network before and after (a TCP connect to 1.1.1.1:443 must fail) and write a log.

First try (the prompt is in prompt.txt; low thinking effort, seed 7, up to 30,000 tokens):
```
HF_HOME=$PWD/hf HF_HUB_OFFLINE=1 SEED=7 sandbox-exec -f nonet.sb .venv/bin/python run_test.py run2 30000 low
```
At "medium" effort our first run spent all 16,000 tokens thinking and never wrote the file.

Open `run2-flight-sim.html` in Chrome with the console open. Ours failed with a
SyntaxError, so we pasted the error back (run4-error.txt is the exact message):
```
HF_HOME=$PWD/hf HF_HUB_OFFLINE=1 SEED=7 FIX_FROM=run2 sandbox-exec -f nonet.sb .venv/bin/python run_fix.py run4 30000 low
```
That one ran but drew nothing (a WebGL error), so we pasted that back too (run5-error.txt):
```
HF_HOME=$PWD/hf HF_HUB_OFFLINE=1 SEED=7 FIX_FROM=run2:run4 sandbox-exec -f nonet.sb .venv/bin/python run_fix.py run5 30000 low
```
run5 worked: mountains, a lake, sky and fog, a HUD, keyboard flying. Your errors may differ
(sampling isn't bit-identical across machines): write whatever Chrome shows into
runN-error.txt and run the next turn the same way. A second fresh attempt of ours (seed 11)
also had a bug, so expect to paste an error back.

## 3. Fly the one it wrote
Open `flight-sim.html` in a desktop browser (no network needed). W/S pitch, A/D roll,
Q/E yaw, Shift/Ctrl throttle, R restart. The cockpit-view key (C) didn't visibly switch in
our recording.

Links: https://thinkingmachines.ai/news/inkling-2-mini ·
https://huggingface.co/thinkingmachines/Inkling-2-Mini (Apache-2.0) ·
https://huggingface.co/mlx-community/Inkling-2-Mini-4bit ·
https://github.com/ml-explore/mlx-lm/pull/2086
