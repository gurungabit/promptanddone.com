"""Offline Inkling 2 Mini run: build a single-file flight simulator.

Run with HF_HUB_OFFLINE=1 and HF_HOME pointing at the workspace-local cache.
Writes raw output, extracted HTML and a JSON log with timings next to this file.
"""
import json
import os
import platform
import re
import subprocess
import sys
import time

import mlx.core as mx
from mlx_lm import load, stream_generate
from mlx_lm.sample_utils import make_sampler

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "run1"
MAX_TOKENS = int(sys.argv[2]) if len(sys.argv) > 2 else 16000
EFFORT = sys.argv[3] if len(sys.argv) > 3 else "medium"
MODEL = "mlx-community/Inkling-2-Mini-4bit"

PROMPT = open(os.path.join(HERE, "prompt.txt")).read().strip()

log = {
    "tag": TAG,
    "model": MODEL,
    "hf_hub_offline": os.environ.get("HF_HUB_OFFLINE"),
    "machine": platform.platform(),
    "chip": subprocess.run(["sysctl", "-n", "machdep.cpu.brand_string"], capture_output=True, text=True).stdout.strip(),
    "mem_bytes": int(subprocess.run(["sysctl", "-n", "hw.memsize"], capture_output=True, text=True).stdout),
    "mlx": mx.__version__,
    "max_tokens": MAX_TOKENS,
    "reasoning_effort": EFFORT,
    "sampler": {"temp": 0.7, "top_p": 0.95, "seed": int(os.environ.get("SEED", 7))},
    "prompt": PROMPT,
    "started": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
}

import socket
def net_probe():
    s = socket.socket(); s.settimeout(5)
    try:
        s.connect(("1.1.1.1", 443)); return "OPEN (connected to 1.1.1.1:443)"
    except Exception as e:
        return f"blocked: {e}"
    finally:
        s.close()
log["network_probe_before"] = net_probe()
print("network:", log["network_probe_before"], flush=True)

t0 = time.time()
model, tok = load(MODEL)
log["load_s"] = round(time.time() - t0, 2)
print(f"loaded in {log['load_s']} s", flush=True)

FIX_FROM = os.environ.get("FIX_FROM")
if FIX_FROM:
    # FIX_FROM="run2:run4" = earlier assistant turns in order; runN-error.txt = the user message that followed each, ending with this run's
    prev = FIX_FROM.split(":"); errs = prev[1:] + [TAG]
    messages = [{"role": "user", "content": PROMPT}]
    for p_, e_ in zip(prev, errs):
        raw_prev = open(os.path.join(HERE, f"{p_}-raw.txt")).read()
        answer = raw_prev.split("<|content_text|>", 1)[1].split("<|end_message|>", 1)[0]
        messages += [{"role": "assistant", "content": answer}, {"role": "user", "content": open(os.path.join(HERE, f"{e_}-error.txt")).read().strip()}]
    log["fix_from"] = FIX_FROM; log["followups"] = [m["content"] for m in messages[2::2]]
else:
    messages = [{"role": "user", "content": PROMPT}]
prompt = tok.apply_chat_template(messages, add_generation_prompt=True, tokenize=False, reasoning_effort=EFFORT)
log["prompt_rendered"] = prompt

mx.random.seed(int(os.environ.get("SEED", 7)))
sampler = make_sampler(temp=0.7, top_p=0.95)
ids = []
text = []
stamps = []
t1 = time.time()
first = None
last = None
for r in stream_generate(model, tok, prompt, max_tokens=MAX_TOKENS, sampler=sampler):
    if first is None:
        first = time.time() - t1
    ids.append(r.token)
    text.append(r.text)
    stamps.append((round(time.time() - t1, 3), r.text))
    last = r
    if len(ids) % 500 == 0:
        print(f"{len(ids)} tok  {time.time()-t1:.0f}s  {r.generation_tps:.1f} tok/s  peak {r.peak_memory:.1f} GB", flush=True)
gen_s = time.time() - t1

raw = tok.decode(ids, skip_special_tokens=False) if hasattr(tok, "decode") else "".join(text)
plain = "".join(text)
open(os.path.join(HERE, f"{TAG}-raw.txt"), "w").write(raw)
open(os.path.join(HERE, f"{TAG}-plain.txt"), "w").write(plain)
json.dump(stamps, open(os.path.join(HERE, f"{TAG}-stream.json"), "w"))

m = re.findall(r"<!DOCTYPE html>.*?</html>", plain, flags=re.S | re.I) or re.findall(r"<html.*?</html>", plain, flags=re.S | re.I)
html = m[-1] if m else ""
if html:
    open(os.path.join(HERE, f"{TAG}-flight-sim.html"), "w").write(html)

log.update({
    "first_token_s": round(first or 0, 2),
    "generate_s": round(gen_s, 1),
    "generated_tokens": len(ids),
    "prompt_tokens": last.prompt_tokens if last else None,
    "prompt_tps": round(last.prompt_tps, 1) if last else None,
    "generation_tps": round(last.generation_tps, 1) if last else None,
    "peak_memory_gb": round(last.peak_memory, 2) if last else None,
    "finish_reason": last.finish_reason if last else None,
    "html_chars": len(html),
    "html_lines": html.count("\n") + 1 if html else 0,
    "external_urls_in_html": sorted(set(re.findall(r"https?://[^\s\"'<>)]+", html))),
    "ended": time.strftime("%Y-%m-%d %H:%M:%S %Z"),
    "network_probe_after": net_probe(),
})
json.dump(log, open(os.path.join(HERE, f"{TAG}-log.json"), "w"), indent=2)
print(json.dumps({k: v for k, v in log.items() if k not in ("prompt", "prompt_rendered")}, indent=2))
